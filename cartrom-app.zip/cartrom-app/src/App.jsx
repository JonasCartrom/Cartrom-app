import { useState, useRef } from "react";

/* ─── CARTROM BRAND COLORS (from real logo photo) ──────────── */
const C = {
  navy:    "#1B2F6B",   // azul marinho escuro — painel esquerdo da logo
  blueMid: "#1B2F6B",
  blue:    "#5BBFCF",   // azul ciano claro — painel direito da logo
  blueL:   "#7ED0DC",
  green:   "#5DB840",   // verde — meia-lua superior da logo
  greenL:  "#72CC55",
  greenXL: "#EBF7E6",
  blueXL:  "#E0F5F7",
  navyXL:  "#EEF1F8",
  white:   "#FFFFFF",
  off:     "#F7F9FC",
  gray:    "#6B7A8D",
  grayL:   "#B0BEC5",
  grayXL:  "#ECEFF1",
  line:    "#DEE5EE",
  text:    "#1A2A3A",
  soft:    "#4A5568",
};

/* ─── TABELA FEFCO COMPLETA ─────────────────────────────────── */
const FEFCO = [
  {
    grupo: "Série 02 — Caixas de Papelão Ondulado",
    modelos: [
      "0200 – Bandeja / Tampa simples",
      "0201 – Caixa Regular (RSC) – fundo e tampa com abas",
      "0202 – Caixa com abas iguais sobrepostas",
      "0203 – Caixa com abas sobrepostas (variante)",
      "0204 – Caixa com abas internas sobrepostas",
      "0205 – Caixa com abas reforçadas",
      "0206 – Caixa com abas cruzadas",
      "0207 – Caixa com aba interna dupla",
      "0210 – Caixa com encaixe de fundo",
      "0211 – Caixa com fundo fixo e tampa de abas",
      "0212 – Caixa com tampa deslizante",
      "0213 – Caixa com encaixe lateral",
      "0214 – Caixa com abas diagonais",
      "0215 – Caixa com corte diagonal nas abas",
      "0216 – Caixa com fundo semi-automático (1/2 automático)",
      "0217 – Caixa com fundo automático colado",
      "0218 – Caixa com fundo automático e tampa livre",
      "0220 – Caixa telescópica – corpo",
      "0221 – Caixa telescópica – tampa",
      "0222 – Caixa telescópica completa",
      "0223 – Caixa com painel duplo",
      "0224 – Caixa com aba lateral",
      "0225 – Caixa com encaixe frontal",
      "0226 – Caixa com aba de fechamento em H",
      "0227 – Caixa com fundo 1-2-3 (pop-up)",
      "0228 – Caixa com fundo automático e aba de fechamento",
      "0229 – Caixa com encaixe de aba",
      "0231 – Caixa com alça de transporte",
      "0232 – Caixa com perfuração para alça",
      "0233 – Caixa com alça integrada",
      "0234 – Caixa com painel visor / janela",
      "0235 – Caixa display com frente aberta",
    ],
  },
  {
    grupo: "Série 03 — Caixas com Tampa Separada",
    modelos: [
      "0300 – Tampa simples (bandeja rasa)",
      "0301 – Tampa com abas laterais",
      "0302 – Tampa com encaixe",
      "0303 – Tampa com aba frontal de travamento",
      "0304 – Tampa telescópica profunda",
      "0305 – Tampa com reforço de cantos",
      "0306 – Tampa com reforço lateral duplo",
      "0310 – Caixa e tampa separadas (conjunto)",
      "0311 – Caixa com fundo fixo e tampa encaixada",
      "0312 – Caixa de papelão com fundo e tampa colados",
      "0320 – Bandeja com tampa articulada",
      "0321 – Bandeja com tampa colada",
      "0330 – Caixa berço (fundo e tampa encaixados)",
    ],
  },
  {
    grupo: "Série 04 — Caixas Tipo Pasta / Maleta",
    modelos: [
      "0401 – Caixa maleta (pasta) de peça única",
      "0402 – Maleta com aba de fechamento",
      "0403 – Maleta com fundo vinculado",
      "0404 – Maleta com painéis reforçados",
      "0405 – Maleta com divisória interna",
      "0406 – Maleta com alça",
      "0410 – Caixa tipo pasta – fundo automático",
      "0411 – Caixa pasta com encaixe de tampa",
      "0412 – Pasta com janela",
      "0420 – Caixa com aba dupla e fecho",
      "0421 – Caixa display maleta",
      "0422 – Maleta com base reforçada",
      "0426 – Caixa com fechamento tipo envelope",
      "0427 – Caixa com aba de fechamento cruzado",
      "0430 – Caixa com painel aberto / display",
      "0431 – Display com base fixada",
      "0432 – Display com janela lateral",
      "0435 – Caixa com divisórias e fundo automático",
      "0440 – Embalagem tipo livro / book wrap",
      "0441 – Embalagem tipo livro com encaixe",
      "0450 – Caixa com fechamento tipo trava",
      "0460 – Caixa hexagonal",
      "0470 – Caixa octagonal",
      "0471 – Caixa octagonal com fundo fixo",
    ],
  },
  {
    grupo: "Série 05 — Caixas de Cinta / Sleeve",
    modelos: [
      "0500 – Cinta / Sleeve simples",
      "0501 – Cinta com aba de encaixe",
      "0502 – Cinta com fechamento lateral",
      "0503 – Manga externa deslizante",
      "0504 – Cinta com painel frontal impresso",
      "0505 – Cinta com janela",
      "0510 – Sleeve com fundo incorporado",
      "0511 – Sleeve com tampa integrada",
    ],
  },
  {
    grupo: "Série 06 — Caixas de Múltiplas Peças (Pré-montagem)",
    modelos: [
      "0601 – Caixa de duas peças (corpo + fundo)",
      "0602 – Caixa de três peças",
      "0603 – Caixa de peças separadas com encaixe",
      "0604 – Caixa com fundo e laterais separados",
      "0605 – Caixa com reforço lateral separado",
      "0606 – Caixa com divisória e corpo separado",
      "0610 – Palete / plataforma de papelão",
      "0611 – Suporte de palete com papelão ondulado",
      "0620 – Caixa modular desmontável",
    ],
  },
  {
    grupo: "Série 07 — Caixas Pré-montadas / Automáticas",
    modelos: [
      "0701 – Caixa automática simples",
      "0702 – Caixa automática com fundo colado",
      "0703 – Caixa automática com tampa integrada",
      "0710 – Caixa automática tipo RSC (fundo automático)",
      "0711 – Caixa automática com aba de fechamento",
      "0712 – Caixa automática com duplo fundo",
      "0713 – Caixa padrão correio (e-commerce) – tampa dobrável",
      "0714 – Caixa e-commerce com fundo automático",
      "0715 – Caixa e-commerce com abertura fácil",
      "0720 – Caixa automática display",
      "0721 – Caixa automática com janela",
      "0730 – Caixa automática com alça",
    ],
  },
  {
    grupo: "Série 09 — Acessórios e Divisórias Internas",
    modelos: [
      "0901 – Separador / divisória simples",
      "0902 – Grade de divisórias cruzadas",
      "0903 – Divisória em L",
      "0904 – Divisória em U",
      "0905 – Divisória com encaixe",
      "0906 – Divisória de fundo",
      "0907 – Berço / suporte interno",
      "0910 – Forro interno de caixa",
      "0911 – Forro lateral",
      "0912 – Forro de fundo (pad)",
      "0913 – Forro de tampa",
      "0920 – Cantoneira de papelão",
      "0921 – Cantoneira reforçada",
      "0930 – Tubo de papelão ondulado",
      "0931 – Tubo triangular",
      "0940 – Espiral / mandril de papelão",
      "0950 – Calço / espaçador",
      "0960 – Lacre / fechamento de papelão",
    ],
  },
];

/* ─── DATA ──────────────────────────────────────────────────── */
const LINHAS = ["Linha Convencional","Linha SEC®","Linha Prime","Linha Supply"];

const ONDAS = ["Onda A","Onda B","Onda C","Onda E","Onda F","Dupla BC","Dupla AB","Tripla ABB"];


const SEGS  = ["Automotivo","Alimentos & Bebidas","E-commerce","Eletroeletrônicos","Cosméticos & Higiene","Farmacêutico","Industrial","Varejo / PDV","Outro"];

const BLANK = {cliente:"",segmento:"",linha:"",modelo:"",comprimento:"",largura:"",altura:"",aba:"",onda:"",cores:"",observacoes:"",fotos:[],fichaTecnica:null,fichaStatus:"",fichaReprovacaoMotivo:""};

const SEED = [
  {id:1,cliente:"Renault do Brasil",segmento:"Automotivo",linha:"Linha SEC®",modelo:"SEC Estruturado",comprimento:"480",largura:"320",altura:"260",aba:"45",onda:"Dupla BC",cores:"Sem impressão",observacoes:"Peças metálicas. Reforço interno com espuma.",fotos:[],fichaTecnica:null,fichaStatus:"aprovada",fichaReprovacaoMotivo:"",criadoEm:"2026-03-18"},
  {id:2,cliente:"Natura Cosméticos",segmento:"Cosméticos & Higiene",linha:"Linha Prime",modelo:"Prime Display (PDV)",comprimento:"300",largura:"200",altura:"400",aba:"35",onda:"Onda E",cores:"4 cores — Pantone 485 C, verniz UV localizado",observacoes:"Impressão 4 cores. Verniz UV localizado.",fotos:[],fichaTecnica:null,fichaStatus:"reprovada",fichaReprovacaoMotivo:"Medida de altura incorreta. Corrigir de 400mm para 380mm e reenviar para aprovação.",criadoEm:"2026-04-05"},
  {id:3,cliente:"Mercado Livre",segmento:"E-commerce",linha:"Linha Convencional",modelo:"0201 – Caixa Regular (RSC) – fundo e tampa com abas",comprimento:"350",largura:"250",altura:"200",aba:"40",onda:"Onda B",cores:"2 cores — preto e amarelo",observacoes:"Alta tiragem. Fita de segurança inclusa.",fotos:[],fichaTecnica:null,fichaStatus:"",fichaReprovacaoMotivo:"",criadoEm:"2026-04-22"},
];

const LC = {"Linha Convencional":C.blue,"Linha SEC®":C.green,"Linha Prime":"#7B1FA2","Linha Supply":"#E65100"};
const LB = {"Linha Convencional":C.blueXL,"Linha SEC®":C.greenXL,"Linha Prime":"#F3E5F5","Linha Supply":"#FFF3E0"};

/* ─── ICONS ─────────────────────────────────────────────────── */
const BoxIcon  = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>;
const SearchIcon=()=> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
const BackIcon  = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>;
const PlusIcon  = () => <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
const CamIcon   = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>;
const EditIcon  = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>;
const TrashIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>;
const ChevIcon  = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>;

/* ─── CARTROM LOGO (PNG transparente — imagem real) ─────────── */
const LOGO_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAR0AAADICAYAAADV7jVTAAABWGlDQ1BJQ0MgUHJvZmlsZQAAeJx9kLFLw1AQxr9WpaB1EB0cHDKJQ5SSCro4tBVEcQhVweqUvqapkMZHkiIFN/+Bgv+BCs5uFoc6OjgIopPo5uSk4KLleS+JpCJ6j+N+fO+74zggOW5wbvcDqDu+W1zKK5ulLSX1jAS9IAzm8Zyur0r+rj/j/T703k7LWb///43Biukxqp+UGcZdH0ioxPqezyXvE4+5tBRxS7IV8onkcsjngWe9WCC+JlZYzagQvxCr5R7d6uG63WDRDnL7tOlsrMk5lBNYxA48cNgw0IQCHdk//LOBv4BdcjfhUp+FGnzqyZEiJ5jEy3DAMAOVWEOGUpN3ju53F91PjbWDJ2ChI4S4iLWVDnA2Rydrx9rUPDAyBFy1ueEagdRHmaxWgddTYLgEjN5Qz7ZXzWrh9uk8MPAoxNskkDoEui0hPo6E6B5T8wNw6XwBA6diE8HYWhMAAKAlSURBVHic7H13fF3Flf/3zNzX1IsluXcb3MA2xqYj0QklhCCRXjeQZZPdzW6S3d+2JyW/zS/ZTQ8hGBJSCAGkBELvlsAG27jhCu69yOpd7907c35/zNz3nmTJ3QE578tHSH7l3rn3zpw553saIY00/oJgZgJqBFGFAgCCgOb2ufXu3n9o62opamluvYLc4LZRI869elTOqGYAICJ+f0edxumE834PII2/DjAz1aFOEpEHQDF3jTyEPdc1NzV8cdne2gWtvYcDrZ3NqD9Qj6kjZ50/VkwdQURNzCwApIXOWYS00EnjjIO5WhKRAuAxc95Bd8NXNrQu/5f2nsasfQ27Ud94EHHq0RQAlAOmkCuccO8EABsA0Ps8/DROM9JCJ40zCmYWRKR6+NDEbnR9ZtW+lz/f1H1g7M6D76Ij3uzJDIdEhhRCsgARuFd5GTkZ5GksAPAM0kLnrENa6KRxRmC4GxAR6Rbe+fl93bv/377m7SUbNq9Fe6xJORlCOFmOo4ULCA8aALEDAsCaIQmx9/kS0jhDSAudNE47UgXOQbXht3s7tn1m2Zo3cbh7jydDkIFckkweFBwwNMACTMJ8Fwwyr6Y1nLMU4v0eQBpDGlRdXS2tkAHgC5xKIiK9s2vlb3c3vfuZV996ymvuPcDBbOnIMBPLGJjMD8DQ0FDwoOFBCwUWDGj9Pl5WGmcSaaGTxgmDmSlaW+sA4IqKCuW7tJmZCASiKr2ldeVvdzS++5m61S97nBl3wjlMJDyANIgIIAEGmb/Nl8HamFYaClr4QqfufbnGNM4c0uZVGscNZqaamhqR4omihoaGOTt27Nh20UUXtdehTjIY29vXPLS3bdunV2xa6gayRUAEFZRywdTfYmIwJ/4C2X8wpzWdsxlpoZPGMcHMVFmZGmPD+e/tPPjF7/7gZ58tyMmcedEFsz/MzM8Qkbe3e8O/tuv6T6/c9GY8nCuDWsTBrEFkSBojeMQRhA0zwASj+aSjcs5qpIVOGoOCmamuLiFsPGYuWLel/voHHn76e4sWLRqzYuUyfO4Tdx6YOmn6BiLiHq6fvGbv219fuWOxciI6QNKFsZkIgATI114IRrcBYIwsANxX2Ii05X+2Ii100jgCzEyVfYVN/oo1275474NP/P3iN1eOWbJ0BQ7s2Bb72KcrQjd/uOL/RvIiO5g5tLnxrcf3N28ujFGbCmVIcrkXIMBTgCSBhEOKGSACgyFAICYYLsjKHaK0eXUWIy100kggGmWB0jqRKmyWr9n2xR8vrPn7N5esHvP64hVo7exU4XAEI8ZNCc057/wtc6aP+j0AHFKb/7FFH5q7q2GzF8hhx+U4tCAwMwQZNzgRgQFoZgiihJHFAIhEQtMx1I+v6ZT+ZW9CGmccaaGTBphZVFbWiaoq8lAFzcz5i1fv/NKP7n/iK0uXrx6z6PW30NzS42Vl5suC/OGyo7PFmzJlAmbMmLKMiDo6+FDJrsb3/mn91jVMYRZaaF9l8c9gYm/YFzB9GR0igjR/gdPROWc90kLnrxjMLGpqash6ozQzT1m2es/t3/vpH/526YpN45a8uQqtrR1eVnaezC8sckgLsI4j3huj6dMne+edP/VRAOhRHbd2ek3FTV0HPScXjgcNAQnSbOUOg4nBWvhqTB8QAxDGxFJGLP0lb0Maf2Gkhc5fIfoJGzDzrMUr37v7f37+aMXSZRuL3nh9BTq6eryMjFxZWDDSYTC01iAE4CninOwMOW50Sf2Y4tzXmDdk7exs+T/b973H7LiChYRWDM0ehPCFB0EzW3FiTK6ktpN0kxOsAALSEWRnMdJC568IUWYxo7+weXvLP3z3x498evHSFcGlb7+DtnbXy80uknkFuY7WEq5mAMoqKISenh41ecJIp7i4aDkArw3ZY1ta94xram0kERJgrUGKwEKD2fqlNAASgBhEyzmO19I4e5AWOn8FYGZRUVFBVSnCpm7Zln/41vcf/vQbb64KLnt7HeKe8rJz8mV+YcjRWsAjAkkAGgBLMGkQeYi7HoYNK8CkCeM6iIjrvW1XcFChx+30RIZwFCuAlFVgNAxPY7QckcLxWAdWAv1YHqRVnbMXaaFzFqO6mmVFBSkiEyATi/GsV2tX/0PVd3716SXL1weXr9qImAeVkT1MhKTjgAlaSwASrBVAntFQmAFoEGmAGXk52cjODr8IAHEVd7q9TqEprkESTIAgDbChhjV0wh2ulAIASCmMe5xTYnMSQgqgATSiNM4epIXOWYjq6mpZUVHBFRWkpJRo7/Hmvfbqqsr//Pb91y59e31w7fr34OqAimQWi2BmUCry4GkNAQeAAFhAgAFIE7PnCwTNAGvk5mQhOzMCAOjV3dzjdUMLk1NleBlKxvml8MJEhs9hPrr9dKz30xjaSAudswhW2GiThAnsPdx7y/Llq77x79GfXL50+QZsfG87FIdUZlaxCImwVArwFIMkQZA05AsxQIaPSZpGBJAEGa2FHMfRmTlZnYDRXpgYEGRMJgDm//YvSpLJvnbTl0juCwanc6/OcqSFzlkAK2xURUWFCgYD2Li1/tYlS9755Pd/+FBF7etvYsv2/UxOls7IHCEgHMlaQisCQ5nAPRZg1skYGQEYFUWDWYAhjNkEwYFwRHZ0tLWPHJb9JgCEwmFPUhDEEgQJZg8AgWxgoI/Uv01+FSe0IQIl4nf8IMI0zl6khc4QhZ8XVVZWpioqKhQzi02bG29Z+c66f/7pz357+aLXV2Pztj06GM5ARvZwQSIkNQPaY/g2k+FOTEkJIkvz9nFlSwgQFMimMQCSCFLIxDgiMjOYFcyCZAcEhiluIVLGmTJm2HOn0sYMCCIon88BGW0rcYi603jX0vggIC10hiCqq5OFzh1HYt3WfR/75SPP/+cbi1dNf2vZOuzZ16iCwVzkFYyRJseJoKy1QkQJuWK0D5v+7b9oHE5+6DDARoT4fI0QAo4MwH4CGQhupniAg8gQSveAHE5wQASCRoqZRDabvJ/rivp5ssy30+bV2Yq00BlCYGYiIraaTdaWfS1fqHt1yUe/851fXFG3eCX2H2hWoax8ZOSNkoIdMAHMRujAmjsEbQL9qG+QHvdVScz/tC1DIYyGIkik0jUaALIxZplQm7fnZRVPbvb2aUgWyUJdAHFS6yHiAYlktqYWs4ZmE4iYljlnL9JCZwiBiJiZnfWb62/+9R9e/q9lK9fOeemlN3Bgf6sORfJQWDBOKqHB5AIEKCaTSAkkrRpOVutLVu0bICaGEl9A4gBEqeaSTQin2LamNdVFucX/p7V+nxYRIRRUQlMSfmGulCP1h292pWphaZy9SAudIQDbxkVv3Lp7xkOPvfDHuroV5y5eshp799d74UieyCkYIYgC0Bpg7Zk4GQEAAtAMEg4AAmk6ok7NoO5pTqo0vkDwBZfuFzI8qmD4g7vqM/9FICgFXGZSZFOuoP20BwAqLVDSQDrsc0igrq5OAEB9fcuXH6957tyHf/PHeEu7p/OHjXNCkQLhMhDTHlgQSATAHAC0sOkEwmg32vAzrLX5YWNmGaEzkB5iXeZIMX/AR2SB19ZGnTCG7ynIK3m+pGA0q7jQEiHAfl6jv9lGR3inyPJO/jnSOLuRFjpDCJ6rgp0dvTojr1iEIrlCaYLWDEEBCPjddyXAQbB2wNoxkcGJYD1tfVEKYIVEsiX0AAlPxmWe+rr5i/rQLdnZtxAR6eFFo38zffwsQd3EpAEwQZOCJg0l+gsTQl9yiIyJx4ZAZjCESNfTOVuRFjpDCMysHccRSjM8T1maxfAg4ijlPbXW9qe/ADkx+GJCpHz5ggsuUMwsRzhTn8/QOa9NGDnZifd6isiUsWBh3OhMdMxzGg2IBix/kcbZg7TQGUIgEgQWIAgICoCE7MP1GgF0tJ9kRDCY0Z/OSfUs9f+ueQ2J7ybHRJqIVGVlZXxywcUfH1MwtTlL5JPqJi1Z2kgfE8s8GDgZypwo4J72Xp29SAudIYSkAiBhHp0wTAgxNADF5relb1K+N9iCT9ayGSx6uM/5ARAzFCvAioX9+/dn7Nmzp6CqqkoTUUNx4bi/u3D6VUL2ZmjdKVh4BGhlCnqlkQbSQmeIQdgfY4aY7G0BIgEhxHGmD1Cf376A6S9nfJOM+wgLIs/zdE5OXrilB7MBoL4zdkdXMLJz7f79HwaA0aHpj2WHir+x4PwrHeGGtOoFyCMIMDhh5ukUwZY6Zk5cWRpnL9JCZ0ghCAgHDAkQWde1A4IDwRISEoIFBJsOC30JWwJDQENAQ4ITwssHg6HAUCbh07aLISaTXW7eZxEIiM7unlh+BNsBgHLy5Y7G1pw9DS2/a2A+FwCmZM3+flHWmK/Pm1kqEc+MezHJrIQli21+FciWvwiAEskWDGgBoQSc9NQ8a5F+skMOVqPpw9Ekf58O+HE1iX/7Paksca08zQB6AIACIdXW6/H6PQey1u09vHgvcxkATMqe+4OxRZP/89bS24MRzlG9PVCkHMiEUDTn0GAoYrAk4/InaWr4pHHWIv10hxDMw0pGBfvlJ3we51g/x91pYdCKfmy6dZp/SABwFedwKItaEPCWbd8zbPOB5kVbPf47ABgTOO//jQyOve/Gi251Jg2fLr0eUsqVLBAwkdKCAakAaVzzQgAk2HfWp3GWIi10hhA0rBaS0riuv4fptIBTvFRWI0kEFWrtVwBUACAC4oYercHBTNkUF7pu/Wbe2dx57w7mTxORyqbJf1eSOe7Gi84pW1J64U0yN1BCsTZ4OiZZaAeOduCwhASBWICEtMJRpJnnsxRpoTOUkBAClqPx3dtniHglWLNNGxKYwRSP96q83JzMhhbvIgBgSZIFEPcACmSILi2xaPVatbWh63fret0HmFnk0YQXQ8G510/KP+8/r5h1w94FM650spFPuh2e7pZKuCEEOQMBCoNUCIICYMnpFJ2zFOkHO4TgixiQTwkb6vdYQudky39qABDaRNkQACh4WnEgGHS0onz7tiGyYQqByXAmxd2YeO3td9Tscyd9qaswb8Y+5q+MIloD4P8y8/0FGcMqR+SM+kxLb332rgN70dRcDzfW6cmQJKkEEGcNhaaTGnQaH3ikhc4QBKfmTB2nkuNX6xss2ndAwWQ9WKbSRfJ9pRSY4dkPgUDGZS8ENBgUiJCWAblqyy7VOmLYJW2Fucvfae+Nnp8d+iERNQL4Si+3/bQNBz+SExhT2lnSckOXbnYOtzThcHsrejsB1U6L7enS9M5ZhrTQGVKwuUopjetstM3An+VkxWLzhaMVmLDfIkrU2/FhIoatB0ubc7u6b844kwCRAyaGZgKEAyfgyO2HW9TB+obAuePHfKc1N/Nz+5j/3yjgaSLaAuB7AL7XyYfnNruHbymMtFw7OtIzJ6hCe2RE7GfDlKe5nbMMaaEz5JAiDE70q0x9EzgHKJI+kMZDZPLF+6hVCTYwKcjYZoub42loEpCRTBmLx3jN9r16X3Zkapurf70zEly/Je79flhAvlRAtDaLilcDWA2gipnHA2glotYos6iy7XPSOHuQFjpDDrbYFfoKCjqutphHpjocPUWiXwkK35pjBrTpYeUHLBNrEGs4NoaICdCQUORAhkIknCzZ7MX1W5t2clF2ZNaYYfnfyws5317Z2vl0Xji8clJI/l4Q7SeiXf75qoh0NbMssqctBbiuro5KS0tTL1bT8V18Gh8QpIXOkEJSq/ATIzUnq4sO+q2E9nJs88oINSBhnvl/I9lrPLVGjh9GyP6bvi1HZK05ggJAQkJQSIhIEId6Y/rwjoMcZA4OL8m/Y3hBzh1biL/5ZmPHprysyLNZIfncGGCHuU7qPuZdsUXOjvW5ND4YSAudIQxKVlA/8e+S+e6R1lQqjWKqBdq6pPCLevX/tF+Yi/weWUBSBUrU7DEJqUoAIhQScAJwPcW7Gjv0zsPNiASdgsLMzMtK8nIv4+7O/5sRCjblZmfg9YOtbxTkhLtZywat1RshSIKjOBgMIQC4IQdLiKjzhG9AGu8b0kJnKIFgzSjDxWitAeH0qb/VtyZyf2GUIlD8Kn6Jt/zj+p9LHATJTxrNR/Q3u8gXYiJZ1nQAhYqFSXVQYGgh4QQdIicgiTVcMO/vjOu9zYc4IMkJBWMloaYO5OVklIdbgnCIIMFfD5EAScARAGK9yCTv4Lq9h//mvDHFz1czywrbrz2NDy7SQmdIwTMJmVBgv/IfpwgGMrV2jEaStDb6dnwYRCtissdGymdhhYcAyBDDzCbnK9n5ys9ST+l3lTDJ+iEhD01RL5cJQphmf4pBFAxIETQOsh6t0ON5aGvsUNDKJJ6yJmnHKdiD7u72Zk0YOSInU38MwPNFJ6PypfEXR1roDDlY9zX1LaYFANAwLX4T+VlJsvhY7XzNoY1wSXZlEIAmaFZISAwim/PlCyi/ApeA7+EmwoANJoBkzjvAtmVxSvgQs+l6Q0QkBQQCABzHfMcWZFU2/4s0wJJ7lGRFwbR5NYSQFjpDEr7G4tdF9l9ly+imFlzv982jCR77sokjTMb4pBpbgF8aVdp+EySTXyVwYmyDFALjI//B/RQU9gWSX74UJrBRaIAEQcMxhcSkAyUdinM6nWcoIS10hhCoT+ErgoAEUg2pFO2HBjBxjpUUSgktiWHKohpy2GguphCXlBJaQ0snYrxKzJ0SgKCUNI2jCJ2+me7Ww5WI8/Ff9ZNNyVeBkCwuz2Aj58AkTX2g/iRTGh9opHeIsw2nJWSFrOljnOMkbMCfEBwOhZ2WlqbOkkK8CQBxpZ5zpLTqibZC78S81wPVczatcwChGUKZnHO/0rKw1qWwkdLE7J2Gi07jL4S0pjOEkWzrkqoB2RWZkgZxTJAfbdy3BTDgMzYioQWBhO/zMn4uIZOKFhGINBSjTzth/8NM+pjalvlskhuCbWfjH9/mYphPEItYrBchJ+8yZnYAKL/18vFdeBrvB9JCZ4jB8qwAbBoDqL8VZcHHrfWwPaYQPhlsVrvP02jWoIS/KtH61xhwShGRDRwUBO2XIx3IZY5UQWlf85lkGK6IwabdFqybPjVFA6avhDmzKfyltQIJKjKXQMx83KXK0nifkBY6Qw1H1RROLlAw8e0+8sAu+JRay+RrH6Zauwcg1cme/OYJ6BmJ8EZfknHK65QabuTzPzZgkbUt7AEwwT2R60zj/UWa0xlqSO051S//yv6V8nN86Btr7HMyDAZDk07hdxikNAeCAQdAPmCyHQzJ67uy/Y4VJw6frwFseVXfr8U+iW5eSRDqLGwOa7o731BCWugMQSTFAx/Rs6rP55iP+ElFX+J2sHWbWj6DyHU9lV9QkHmwJX4xAJCG8AlkBvcpi3HkuQdxo9vPa2aolKGQZptcljyGZt9bRyAhrNaTpnCGEtJCZwjjZOoiD9ZU73gPRdalzikuqtQ1P9iY+mR0pfI0A/DdjCNNNEr5vE9j8dFkZRofWKQ5nSEGE9bSV1ikciKpn+MByBU/VSE1hO941q0pp5E0eWTKWwP9mZojlnoMM/wBghapr6Dx+Rwg+bovnJitM9/nf9LW1ZBCWugMNRyxXmlALcVwr6muZv/7Ka4npAgT7utZSn7H5CiYUhpJQ8snkJVGPCH40Dfi+USFgS94fL7YJ7K5v1hLdCUd3LRM44OLtNAZSpASiYhhu8xZ8ACC6MRwFLYFSEQHC9Og06ecrYQKh5wLtRmPXywDqcGB2udnEjE2xxhLfzmVWqc5dcAQ9g70U5HS+MAjzekMJWhLoZ6sNTEA6Xp0TSHF+EosbPZL6xAAxJXaTkKAQOyT0mdW+7Ai0td2zuCZ0jgzSGs6QxJ9vUOpKy9h0tBgHMqREitpEh2nNEvlXli0SimP5JT8c54BuuVo3FAaH3ykhc4QQ6pQMS7zvvzMycIInj6vpJyU7Sl91xFBK6MlCxIy9VsDaTpE1IcvOh4MGNGcYqpRyu80hhbS5tUQRmLRHWXlnbo2oBPH8b1knuexdESP//5gbvg+Yz2t4iElvijtuRpySGs6QwjMIvEDEJgUJKQRCwlziqF1suunbzr57Eyq9+eI40OlKDjJb5jDKkArDgSF09LY0j4iz1kCAMRQWmsQCMIW8fIo6VEz8TSpmtJA1zWQ1+xIJI5JVgjaImCg9N45lJAWOkMKRtj4PmUmtiUfUs0X60Ni7pMcelz6QB9hxCmupCR5y8xgxcARaVeUSG5PDLHvB453FIN8NHUsfX+nmZ2hhfQWcZbCVN873YFz7GdkAelY4DROEmlNZwghYL1EfTtympwlEn2D5VI/l/Bw2VCZowmigcqZ+nFBDIA12yRzI3SUVtCsobWG5JRI6BOIFj7hIMIUfikdjTz0kBY6Qwx9kjRNsHCCTDbmjRU01Pc7SHGtH4tcPtKTlXgj9QBe6uuaDZeE0xCsmMbZjbTQGULQtuSET8gmkh4TAXxH2jwJXkf4qQMDCJ3+iU+JL/sEMIyAA8CsWYYcB0AegOZEdgQbs0sPmM1FqYc7AoOxMgMRz0ZZ81MjOM3oDEGkOZ0hhWQkrg/Nfr0bPwHBr3zDpoGU/8ODCBwM5PwxtXH8HygN0hqkQfFYXBUUFGQebIxfAgCaIAAyhdmFzdNCX9OHmEzfqqNc1oA//cfJqYJ28M+l8cFGWtMZStBWzyG/r5XfsYHgx8sktINBBMzRkJoflfpVX5vwf2ut+5S2SHzfV3qIjsyhwulKkfKrFx7hIktjiCAtdIYY/IzwRCoEYCvppZZLP7n1eLRCW4nzJ7K/zQcjAXm9Kdz1l/Jm+TFHfKQVl8aQQFroDCUIJLw2gggKsF0XUjK4qc+v44YfcNfvVQD9vFec8F7ZIdEwINWc+guoH+ynVqSlzlBEWugMMSTqAxNg2gADA5fQG0xrGUgwDPRvvz5x6uI2aQdCEgSkjRDUu/zcKr986ulQQY52hL7kcdrGGmpIE8lDDiLF/X0CmeGwnz+iPuiRscPJdr4MZkpEPDuCAFbsur3scTwIAHGNTRAEhmAikWr/nTSSrdpTI5l9rqpPOfojxp/GBx9pTWdIwbi2/exy1gNXDfQ/K6xbKnXxGhPJMkB9YnkSZwCgweSX71EQBEhJ6O1u1qqngaT0SEh10BwcGeQHC/VxLZ3glaVkp6dyxEn55XvubPCiiR4w5HVa7gwppIXOkIJ1iieC9IBBNR0C+AhfeKrL3QYXCoEkf8wgaIAlQAwpCVAKsZ42FevtoHGj8sTHKj4lrrz8gudHFmYtAoBISF7J2rbhPFbQ4WDyyCak9unil9B0KNGWxn/PJLymOM/SdXWGFNJCZ6iB7BYPgeM1Lfq0HxYMSljVpiOnCQ7UAGsQMYQAQAqx7g7V1dHE40aXOJdefDVuuPayjRdfMvs7E8fk1zywapUAoJTGRhKi7HQu/IQs5f4usf7/ShPJQxFpoTMUQal/9ONkBqwSOKiKYfO1FAQ0JGkQ4ujp6dJubzuPGlEkKz5yGy6aP+v1yy6d8+C5E0seIyIFALWmdzh6PSwloq8opZlN/I5pVQXfo3WSF2iP4Ws5ieBCv4XxEVeexlBBWugMJWgNsPBD8JBcdqmubfR5DUhNqBTWKvESkXqSAAQ0JMfR096q3HiXGD2qUFxXdgsunHfeGxdfNOfxaVOKF/rCprq6WlaUlydsG+kgyLABg54HCAkmSkQPp9b1OX7eO9UZ7nM2vklp2xuDoRPhAmn5M5SQFjpDFr5b23qZEq+lvu9X/YMxqfxIYRYQpEAUBzjOvd1dSsc75PSpk+SFc2fgootmv3PF5ZdEJ4zKeJaINACqrq6WFRUVqqKiQiUOCiAzIxiIRIJgMIQQtvtDP84lMZ7jV3s44QVLRjcTI5FzldqGhsCh4z5wGu870kJnCEFBm1wrNhlWxtTQRpgw2YRPkbA9/JAZ37sjiKBJwxECynW5p7dRSycmz5s2ybnikpswb+75L5Zefun3R5UEX4vHXQBAbW2tU1ZW5iWEjUWDlXCFQWwlt1cL0kKQcbdrDCxe2LeZUnDU0hRkklwJIiFwtL0eP1QxGAzBY7wHQEcNw5zWej7gSAudIQRPMZQ2gkfb/uE+qZxMDvCzIh2j4Zj/QQrAcQieG+eu9jYOB5WYP3eyXDBvRsdll1z4+MUL5lQPywu8Yk9F1dUsysuhicgbaCzlVpUZDqwOePH2jIDI6/ZijEAoJT9joCjnvhiofk8yuposvWM1OfYPbXPAmDkYiiCusY6IVC2zM9h40/jgIC10hhCE8BchkhngiXgaWI3HyCLhkypQkJLB2uXmpmaVGSbnovnn0BWXntc+/8Lzf3fjVXN+REQ7/FNUV1eTMaNIDTiIxKmIq5klgI6ivLxXhw+Lf3RLY4t2QkFpxoYUL1niWydwtX1jiwiwMUp9E0ctVZQ2r4YQ0kJniMG0tVMg9oy5xNJ4dkwIL4SVOiTjEFJAud3c2dGqQiFyrrrifOfKS2Z3nH/e9B/cePX5vyKifQAQjUadGTNmsOVsjnssRXV1RGVl/F63V1OcHbpjx2EXEgxhhU2qSTQYCALcn/5J4XD65JQlSmXYHwiACVqrtEk1hJAWOkMQnPixCQoEgDwwMxzpQAhCPN7FHS1tKiODnKuvnOOUXXlRx9w5s35bdsmUhGZTXV0tN27cyFVVVSdlkpSWlioAdE5ELtpJaMwPhgq7FViTIAiCZgCsfQkxgOaDgRkY3zTDkQ6vIx1g3C+2Oo0POtJCZwhB6L5+KiZtOWMCCQ0JDTfeo7s7OzgjwvKaK2c7l1wyt+PySxd898qLpz7mC5vy6mpZXV6ufTf4yYKI2PIojSvr2/5nwnD8z/q9TZ7ICDmaGYIADWFNPR44fpCOkj/lC56j6DFG+eHYqVxHGn9ZpIXOEILWDNYKguyCZgUhCcQCrtvLHZ1NKicSdq66cg5Kr5jbfMXF8x65ZME5PyGi7UCKZlNRoU6XalBn8jJoJFB9qL3tv4KIZygVYxKS4Df/5ATFnUBqAfn+6Bt9lEyf6P9JIlAs1oOQzJzNzLLScMtElM7G+iAjLXSGEDQ0BBTAClIAYIYb7+WujjYVDsG57qqLnCsunbf74vlzfn/Fxef8lIgOA8btXVdXp/u7vU8Hqog0M0si2r26sf2BmRPlP63dsd9zsnMcBbbBjABpMh0r7PeO1cXhOKN6KB7vhZRiJgBZRRSv5JPMOE3jL4a00BlCEPZHwoOKdXFbR7POzgrKG6+a71xVdnHHJZdc8NCC2eO+S0SHACAarXWAUl1WdsbdyJpNjMy3Onrd2w/kZIxviMUVBUPS8L8ELaTheMCJ1IajiYeB32JLTPvdRBVHItmIe6oOgFtthN9pF6xpnF6khc4QAmtPe/Fu3d3e4GVnh53ryubLKy+b23DVFZf/z4UXjHsy1YwqN5zNXyRmhYjYmjVtW+P8ic54bHH75l2iV3tMwQgxpOnPRSJBJfvlOQbSeI5I80yxtyiRDWqOZMxMpAXNEEJa6AwB1NnfSvdm5mYHxA03XBq+6eabGmedN/PbV1409WEiagGMZlNZWarej92ejJkliGjp2obmj7pjimrW7GsQXUoIEYoQCUAIE8ho4owA2EqDRwoespUyBipIagqLmbo6knp7exGS8jIATgWRm+Z0PvhIC50hgBkNDQwA+TkZ1V/60idmZWflPH/NVQt+kCpsgFJdVUVeVdX7N04reBwieurdls5/C+cW/G/dO1vYZbATiZBWKpH71Sc/Y0CwDUhOrRPIKX9xMlhQpgtgDiWkSbchhmAggLhr8qJSzKgP1M6+kjkwj8jd2N79b3tbOr+1ause2RzXSkaypCIHmqSxi6Ct3kN9mGNfoKReFcFGWwtDTgulwV6nGpubKeeNGf76JSU5V1cCXAnwB+1+pNEX6S1iCCEajYq46yIajTrMTBUVFeqDuMDmEbm1tbXOjJyM70wZUVR62ayprVNGFEq3s9Xj3k7taBdCawiSILLmliWYyTRnBxQSKR0aSOaZJfgd0xCQpIDH3AKAZwBp02oIIK3pDD0MmfpV1cyygkjVM0/e2xb/6d7Wjhvf27kbzR0xj0OZQoQyBKSAIoZgU5ZUaW21HgFNjETHUEMH2Ux1gmAPOt6pSzIC4opzJrYuKMwsIaJ4mtP54CPN6Qw9DJkFVUGkqpllCdE2AB96z+N7hmcFv7m/uWPc9oPNaOps1SKcwTIYFDZ+EEIIsParA0pTtEtbVzl7JvqaAWgCaeJwMAxXqdUAPEtkH9F5NI0PFtJCJ40zigoiZWN4mIjuY+ZHtudkf744M/OLB5paZzb2eNjf3AwX8JxgSDhOkOAIYk229KmwmaMaghlMbBqoa4bSYCkI7OlGAFyTpguGBNJCJ40zDl/7sJHLbQB+zMw/2ZGXefOhtu6vjswJlHYTBeqbWtDR1Y4Yk8dCAhQUwgkJo/UYgsf0nZCQggAh4EgHDO4URLwoHY08JJAWOmn8xUBG6yEAwsYSPQPgmb3MpZ1xff2BSOjq9q6u83U4Emzp7EVrRy9aO7ts8z/A0/BMLwwJBsNze1zlRsBa6yFjc6aRFjpp/GVhSV5T5J1ZbqwEjyGqg42BPMg8s62n5+aW9mBOvDDr1q6YN6O9sxcxVyGcneNoTXBdDwwPvb2OM7Y4FxlSN75/V5TGiSKtjqbxvqO6mmVROagMUEjxPDEzxYDJDTHAjcVEL4mrNSMc63FZw4OCi6DHsTmjhv2aiHrSnqs00kjjhMHMopbZqa2tTWvhZynSmk4aH1wwJyo9A0DdIN6pUuADGSSZRhpppJFGGmmkkUYaaaSRRhpppJFGGmmkkUYaaaSRRhpppJFGGmmkkUYaaaSRRhpppJFGGn8dYGZRXV0tOV0aIo000jjTiJoCW2mkkUYaZx7V1dUSAJh5clcXX1hfz1nmnbTGk0YaaZxm+Fnc67fsu6Xqv3/R/Y1/+x9+8ZU3/zv1vTTSOBNIT66/QtTW1jplZWXeu1sO3vLw40888cMfLaRJE8bomTOn5wBAXd37PMA0zmqk7fm/MvgCZ8f+1uv/9MwrT/zigceFomxVMny8CGfkmN7npe/vGNM4u5EWOn9FqK6ulmVlZR4zD//DH55+4L4HHnc8ZHIonC+UIoiBWoenkcZpRlro/JWgupplRUWFYubh//uT37/6698+Mbat3VXhSK7UChBCQggzHUrf36GmcZYjzen8FcA2oVPMXPLA75599VcPPzVjz8F2lZNXItkTpnEdRLqOZBp/EZxWoTNYcNn7VUrygzaeU0X/6zme62BmUVlZCWYeUf3k4pfvv//xGTt3Hvby8kY7ricghTDNwjXwQdyDBrhm4DR3OR3q82Sg8Z+psZ/MHOyPU5hlTNEoCKV1YtN997EdgBrkw1ReXi7uueceamho4PLycn0mbgozU01NjQCAipqawcdTXi7LUY7y8nKUl2PQsTAzVVZWHnX/r6ys5FP5PgBUVVUxBllIzCxqamqoouLI6zlW9wN7fnz729/SF15y29P3P/D4zPUbd3kFRaMcj01LdIaCJhcaLphcikajoqGhQUSj0eM2vfvfg+P57jGumWpqakTN0Z7hSYOJGVRXVyfuu+8+rqmp4cFbEZfL8nJg+vTpVFlZyZWVlVxVVXVa2hafwNwY8HzRKIsZM2roKPeIysvLRXl59VHn+LHGWFMDAdSgpqYGNTU1A9SiNvfonnvuobq6On267k//gYhodOA4DmaWzDyy/48QR97b0xV2z8zEzLK8vFwO8F5ogPEcsSAGGsuJLLozkT4QjbJAP4OHmYvtNYxi5mz78oDnZmYqLzfBfy+9vum+Wyr+lWXOpW7xpDu5YOLHOXfCxzl3/J1cMLGCA8OudUtv+gf+0zNv/uB0X8eJIBo16RiprzFzxF7zCPvbzr0Tu+XRaPSIY/tHSTl26k/BIIcStbW1zl8qZaT/ecz66zs3U9Zd4jqk7Dt9T2S9MTNFB4jVCodD6Hee4gG+TgPd5z4fOJ5B2IGIiooaqqmpUP6/AUyoXbzm+paW9lv3Hzws2tt7RgZkcHJHZzuDQcFgCNm5WWDCquElwzonjB/30vmzxr8dCWA5EbmAuRkVFRUntZv1/y4zFx1s6Jm26d33btu798DMpubWsUzO+Pa2VlZKISOSQZ6ntmTn5ByaPm2qN3XalIcmjsh4xba6Heh4xQDCg90SmPvXZr9P9rWEBsLMGQCGpXx2QEgp92itExOspqZGVFRUKCEElFLn1S5Z9+UtW3dMaW1tv7C7pzfc3dnB06ZMOHT9dZdfP2pU0VYA1G+3JiBKQJV+a9X2++5b+Ie/faz6RZWbP0IyQtBE0MwgeJCC0dHe5V08/1znX77+xYc+VDqtqhdwwoB3HI+g/z3w79vY4/jOXnuPiIg4Gq11qqrKPPv94hXv7CjfunPHhw/sOzxRQ4xubW7yiorynIkTRn7ntg9d9S1DjB9bC/K1Jv+52nk7761lmy7auefA9fWNrVmsvQu7OmOitzcG1syhUICcgOhU2ls1YcJYKi4etnbqxHHLJ44rfJuI9vjHNmOANs3WjxtWznE+gGwA3NPTb25Ekr/88zEzVdTUiJrkdUxctnr7F7dt2z1/9859w7XmKe0d7ewEBGVn5yAYCKycPHlC99Spkx+bPqXwKSJqMmM++npLfZ+Zsw82e5du2vDeR/buPTCh/nB9geM4M7u7uxiCKBQIxBwpV4wZM6Jz7OjRTyyYN7VOEO3hY5znuIRO6gHicb7gzeXv3r5yzeqbd+7aM/1QfbOzZ289Wlo70dEVQ3d3Lwim+zQJiYAMIDc3G3mFmRg/dhTGjMjHhAkjN82be/7Tl1449WdEdCAajYoTUcusaiqrqqo8ZnYONfTc8dbylbdteHf71Tt27Rm2b18D9u9vRGtbJ7q6YmDWIAKYNcLBMHJzczF8RAEmTRmJmdPGH5g377wHyhbM+jkRNVZXV8vy8nL91tubrlq9et2ftu3cExEUIe0qYtLwCAAEJIHjsW4+b8akxrKySz86bcro5bCLPxqNisrKSueJp199ZdnyjZd0xbQGQTADxBoEASEcKNWrcrIdeeHcGTW3f/i6TwNJE7WX+ZznX1h239tvr7vqnfXvYevWnTh8uBWsNTpbDusvfLFc/N3fferjF8w65zE/9sa/PwsXrgzcc88Cd8U7O3/xy4ce//L9v3zMyy8c70BGEFcKgiQkAQwXAEN5LnKygrj00tk6PzeoWcUhyQGsssUMs66YobTyJSvAcRUKOXLBxXPWf+qjNywgIveZlxf9esmS9Z9qamrVgWCGEOSAQCDWYAJcr0eFAiwXXHj+c5+48+aKmpoa5avuzDzxpUVr/mnFqo2fXLtxc96WrXtw6FArunu6Ee9t4+HFWfR3X/7Ey//ytS9dX15eLmtqao4qdFIFEzOPf33pu59Zs3bTR3ds33Pe7r0HsGtvPdra4mhr7YDyzHMlACAFRwpkZYeRle1g1OhijB05AiNGFsUmTRqzbP68uU9On1T0GBHV918fx5q3dmfK+tmDj7+zcsX6sQSpNUthJr8CkYYQBE/H1ZgRw2TZFRf+3+uvvvJbFRUVoqamRjV2xRe8+cbKr61avem2dzfvC23evAuNTW3o6u6x4kyBhEBOXg6GF+Vi+jkTcd7MyY0XXTz7NxfPnfJtImofaLy+uVdVVaWZefTSVVu/uGTZms/t3HVw/LZte3HwwGG0tXWhs6MTGhpKuRAkMKwgH8MKszFu/AhMnjw2fuGFs5dcdtm8quKc4Bt2HRxBPxyV04lGWVRVEVdUVKjOGM99a8m6r337fx/42IoV65z1G7ehsakVDOk5wQg5TgjkhCiQkUFkVjhIGM9IU0evPtTWjvXv7mYHniwuyJw+c/rE6aVXzP/SG2+9U3XFJbN/Zj0sxxQ8KZ/zDjfz5Y/+6Y1vrVi5pnTxWyuxbccBdHfHWIiwCoUyScgwBUJZ5AscQYDyPG5o7uD9h+uxbMXblJMTGnnR/LmVa6+64ssbtzVVTZ9U8AAR8YsvL7/62edrc1968XWVmTtcwnbL9oQRqFIQupv2649/5vaRc+dcUExEXF3Nwh9fZWXlOXv3N17x05//BiKUDRIBEASIGWCCFBLa63SyMjUmjhtzI4AQEXUzc+aSZVv+Kxq9/yuvLHo7473NO6FJeo4TpGCwQAgC4jGlNEuwJ2P978/KlSsD8+bNc1esP/jNR6uf/fLCB2vcvIJxAVAYmgEhCEQMAoGZwKzhyCC6Olw8/XSt0DomhAAEhPFoJRQ4BjPDgwKMGAE45iivC04kMPJTH71BAMDePYfmPPrYU87efY06IzNHKC1AJEDEYEGAjjsO4hg9avT1ADIqKiraAPD6jQf+9sc/f/x7L7yyPPvt1ZvR2eOqcCQbjsyhUEY+SSdbZWVIKWW451hzBADKq6tlRQUpZs577c2Nf1/1vYf+denSNZGN727H4YZWgAJeIJRJgUAWnGC+CASlvV5zyVordHS5urWjBzt3bWbXXU2RsBMaNWbYlfPmzrhy/pxZ/77mnT0Pzj5/zLeIKHa8mpe5ERxYt27T8N898qyTEcmGYgKDwPA3JKC3t0lMmVAkLrzg/NuIqIqZefnKrV9b+PPf//C5FxZjw+ad8HTICwTD5ATCFMgMJTh2BtDW5erm1n14Z/1mPPdCYNgVl13w9atKF9yyZXvjV6dOGvZKP43GX1O8Ycv+T/z0ger/rXv97ZHLVmxEc0uPlk4GB5wwpJQkQ3kkWcMBgZnR2BrX9Y0HsXbDTjiB14OTpy6+6sbrrrzy5cXv/OC6y2f/S1VV1RHc46BCxx+IEIRl6/bcdf/CJ+576pnX5Kq1a+Fp7YXDBSIzZyRBSAdkJpa2Og7AiZRBEgKOCMuAiIAyHEAxWjva9Kt1q/Syt9cUfuXLn/hpU1NsERFtPJbgYWZpXb+h2rc2fvcHP77/H59+tg7bduxVjpOBcCRX5OQGiCEcIgcKDE0aRBqstXmoQZCDCAKUASEKEIt188uvrlZLl64b/t7WXb+49eYrr3YcWd7d6zaKYBbLrCIdyi4QggmmCbcAICCFRtzt1RASnmNMxf5QLDiclctOqJBIBqE1gdgIZEcKaC/AmVlMwon0BAJONzMX1Tzz2suPVr8y+5VXVoAppDJzR0gW5HieB9YSIAGmoNkPnb6aam1trTNv3jx31bsHPvrb3/7x2/fd/3svM2eEQyITmhiaPBiVj8zUJJiFxgQKBBAJ5IEBJjI7PnGy1R2DYe6BBhOb7+m49rxWIaUTT6wpKbsiGdmckU06HMkixWbMJAiCANKKA+ihuIcuWGn24ssrv/frh5/45m8eeRKdPcLLyi6W+QUBqRkAB+wQgsQEIiGPyrXZCY6aigq1ftPBm3903xM/euGl1ye/ufRtxF144UiOyM4fKUABR0MbGQAPIA2GAFiCIcEkQCIogxREIJwNsAazx7v2tOr3Nr/Az7/4RtH1pWv+7UPXXXFzUzvfU5hDbwJRwTy4YyF1mMFgVjwztzgSDmezZkEgAZAGaQdCMISEDmXmUVyjMRQK4pmX336ypubZW598epFmZOmM7BIZdhxH29WioUAg84yIEAg4MhgIIxLJA3sxfu7FZWrZ22vP2X+g+eW339n5b/NnT/h/tbXslJZCE5Fm5qyX3lj/vV/88tF7nvzzi2hq7vEyM4tEbkG+UKTA9jwK2mzgOggAcKQjA8iAEAAjjs1bD6vN7z0itm/b+83nXnn7wg9dc2EFETVHo0xVVTS4jzRlcY9/+qVVP/3Zvb+55eln6zgWF14ks0hmOAHHUzCbP5tLJjAESat227lKRggxMaA0mAUIEuFwrsjOzhb19bu8+sMdsrG94xwAG3EUc6+62oypM8bnP/70mz95vOa5K196cYkmmY3cgjGSQWBt9goNw1doAgjWTGCypjcB0GAmKC3gODmUX5DrxHpb+YGHHtPbtm+/46FHXq4dPX7abo8lMZEw1D/bPd/EtDAYmjUxlCDE7LhrAJQn7yNp0lpDKU1m9yRIY5tAaYZSgAdBHlOv63oj7n/4qed/87ua2Wve2eXm5Ix0SISkAqC1a8YuNJglAIJWDH9brUMyvWH3/t4PP/TwH2t++/snEM7MRyAYJqU1fG0FDLDW0L4JTASQgr9DGrkvzd9kxKy5cHPNvoZEIDCIYNZ44rmR1sJTTObegLTVioyWJ8DKgyJFva6nAPS8sGjF07/6zR9veeq5JV5mdrHMzc90tCJozwMJgJkhQCB2oUkgedUDzlsiIpZS4rlXV91/3y8fu/uPT76M5qZOLye/SGY6AUdrAa0JihWICEJIgABDp5kNQVMMIIYAQ8NMabCEoBBlZhbLrKx8uLFOrn7yZbVizbrztu7eu+TttTu/tmD2hB8TQTDzMV3JUgSJIUiDABKkjfUKwWyEPaRQOkhZeSMzflPz5qO/eODRW1957S03J39EQMqIYDDY88ysJABa243fnJYBaDZ/CxGhrPxRTkdPh/7Rvb/TLug7K9fvaZs3i+6z963kTy+8+cqvfvvErNq6FV5mRp7ILyxxtCZoNvOWme2GZWYKk2/Nkz+zQHCQnVsioVx+6pnauOu5Zd3dvT8mok+VltY5VVWDBGb4Aqenh8f/7rHXFv3yt3+a8Obyd7yc3GInKxJ2GIDr+RPJTCuQGQ9YQ2uAyCwMYgEmAUCBYR4yg4yIYolgIEJCBIm0iPcfRyqqmWUFkWqJ8ZyaJxe98pP7flO4fsMOtzB/dAAUhscuWBu1X/iTxSpMIvHoGX6PWgKBiaEVARDQGgiF8igYzpS1dWt1e4tb+tnPR6BUCIIyJHMAxCqx6Ix5AhATSAODrgMFsIIReGw0JEAZ2ceA1oJcTyAnvzjrjy+uWnT/g9Xnvrd5ryooHBeIxwnwCCQJvtpMxBBQMPNZA3Fz4vKGIjGzYma8q4tH3Xv/Y7/6xX2/g+sFdEZWrtTaaBlmIxD+fuhT3vY///hkjCom6CPCYfwFaD9N/rsC0CnOCnZALM357PEAAmuAyQGEoF7lgUKR4MrNzX948HdP3PL0c4tVXv54h+HAdRWkEGAygkFogEkaQSekuZYBEI1GhSWmC3/3+Cs/vvf+hz/1wotvqYysYsorHOUwa2jFAMzGKOz1gq0GDLLPRxrezV+wJOyiUtBa2/cFgk4W5ReFnH0NHfq73/8N9u1r/NGrb7wz5arLzv+q9SIcXfCQv4Z84Q/7ZDRYKwjhCKUCOHiw+5Inn3jykpdeeVMXFo8OaHLgKsPFkRB2kxd2MxLmdd8ctqfSZlEiFCkQJIK4/8FHvdycyHebO3hxfhZ2/em5JYt+8LPfTF+5equXnzfKAQLwlAmnIAASEhra7ltGEAkK2BlhNnF/A2PWEMKhYUUjg88++3o8IxT85KK61bvLrpzz775J10fo+JGrPT084deP/mnRvfc9Nn7L9iY3v3BUQGtAKaOCEgn7sJKPi5jMohb2fbLqOTSYCNABK5UN2a+1gFZmcuEoGk40yqLCaF0jf/XIK6/8z/cfKNy5v8krKBoTUJ4Aa23UdyJo0lDMhkNgablPIxWEZH/tGEHIdjkQgYW1qTWhoGisWLdln/7fnyykYCBMkUgEggHFwqYJMLTQIBYAO0YlT6C8z9i1htUiFIg1hN3NAIBJQxNByBDq63uKXn+jrmjjxt26oHiUjLsaoIAxpdhMdKPyw0wwYoAUlJV2MytmesxcsvA3z712/0OPF3Z0k8rIGSY9xTDhCgxDYktISHMTKGVHhBGKkgkgAc1WFBEnzEGyQtsuVzA0NBM0JDQnhY5ioyWZsfv32QYgCoZiNnNIZOY9+8LSjz73/DKdlTNCakhjfpI5loZZ7FpIEAmwEDD/HemNtRqOZubMR594afn9v3xs0srV73mFRaMdTztQWkEwweyx0vKNbO4tM0jA6mT2vrA1QZmghblD2i4swWaT9cAQLJGZmS/cYAZ+84en3K5Y7z2a5QjHkbfX1NT41sKA85oEQxAgpYSyc5WYjDarCeRE0BMj/PwXv+Ud27dzfsFIobQDxWbGCSntRu+rSAQNBSbzPrGwvBsnNFWlGKFQhujsiuHR6hezJ0yY8EhWZjj+458/PH3Vmp1eQeFYx/MMd2f2pZRn7+szZISLthsNmQcLwLG2gIKCZ9ZS8ZjAn59/3Rs/Ydw365v4uZJCWlpdXS0TQscKHGbmUY/+adFr9/3ikfHbdtZ7BYVjAq5SlmQTADlWxTKaBDFAJCCsoBFkzBzW2kaPEgQZG5nZzj1/oZunPaii4Ae3MXPGbx59+bf3/uLhwn0HW72CwuGO6wKsfQFoJwsxAGEkMQuz4NgsXKUUA8aLRexACElC2MWszQ7ua2HZ2fmiuaUN4HZIRxoNx441qRkQBp5OfcYPzcoKDv/B6YQ6KhwHrmI8/Ic/8p49ezk7r1i4yghFIoHkhLVMGcOobmS0OqWsDsQcqPlz7b2/f+ypc/Yfavdy8kc6nhbweWBKHMcXkP4EMldsJpaAIMdwNjDP2zxzu4tZTcuYqeYY5vH23S80jFlGKZoU+XdOG203HMzCksUredfOfTqSUShlIGxMAcFgTWBIgLUlvR3zzIgSmmo/UE1NjWBmevTJ2gd+fv+jk5av3OwWlYwNeFrAY+1P0oR6ZoZGICEgyDxPrRWYmY2QdIiEWdSsrTZI5vMEmRTIYGitEQxGUFg8MvD4H19wI6HAR16uXfXPV10++we+1XCUGWLmXSLYAvb+SjiOQHtHDxqbWykczDT6OwMCDLP3efBcz9j4RCSdAAlhdGFjCptnbaLSzH01LAcjIzNP7NrdxL95+LlZrGNYvXaHzisY43hMYKGsCW3mBJEGK81au+Y5Sglh1W+tzb+R0BKt+kvGCJZCEmQGPf1CrZw8cfR3mLmsoqYmaV7V1ICYGc+9vOq+Bx96csLGzQfdouLRAVfpBIHpLzrYucasIa2K6sa6dTzWq/2F4gsfwxkISCdAwXCGCAQjxARAmMlgFd4BUVdXJ6uqqrzLym77wVPPLrpm43t73MKSsYF43KiUAkbtBtmdyE4ERwDa7UV3V5dScY9JehQICElkSDBWEp6CJ5wARTLyhBMIk+t5ZqFrDU1AwAkmNhFAQlDKhD0RpHzBbiBmEkBASAfdcRdbdu4lR4ZIOA50iidDCFiTiqGUx8ZidCHJYwHFQpAAgDffXvfxPz/z7B1LFi3uySyaGGzraFHMRi+RQlAkkiklBa2Nz4kRGHbQePXAjO6udu26PRpSQbA0WooVIExkn75lDUhBa08rr0uoeE+C/Fdam/OkCCRjamjDtUkBpYE172wmsJDSybB8imd4FDKbmyCCEBrELptH67IjyOo/SdTW1sqysjLv5TdW/9tTz73xieWrdrnDSiYE4gqAcCAcBrMLrTlxnQIEQRqe28M9vZ0q7nZBSpKBQJAAATcO9pRSjhNAKByRwWCItDTzX9s5TfYZgiQUC0ghUTRiQuDR6hfdosKC72/Z3riLiP40mFdLKzYaJfuCmRIbHyXMJEJGJBNaG2Fvrt1Db1eLirsxhENhmZebK1kD7R3NiLueFwrnyGAw28wasqaPoY0AEBQThGaEI8No+Yr3NEEjI2u48LTZcMhSJUIrdHe2a8/rRSjgCCnM+Ny4huvBi4SyZSAcJpVCX8DyfQwJEgKKCRlZhXLztr3q7dUbrywrnX9RTUXFUgdIxjNs29v5oedfXnJrbd3bXn7x2ICrKEmwJfZn3z5QcATQ093KsZ52XVwyTE49b7IYM3okSkpKEA5HEI/F0NLcjEP1h7F73yHsPVCP9tZGlZmVQ4FQSEC7MErhkfDLMOyv777sx/f+6svPvfi6lzdsfCDuwqrhAj61CzKTmqARkIzOtkYFHRMTx42W50yahBEjihCOBHozszKglUJHa2e4rb3T2bRlB97dshuxnqDKyimQSllTA7A3zwhMQ0SnSBD7i6wdOzi435+cPIwyhyYhIaTZ3bS91xLG40as0NvToWK9nRwKkOM4AkQKXqzZcaRHQcEBAGg+XH+njruYf8mcSChSaJ3aCkEnCMUOdu45xJ1dLpEIGLMBGoZs0kYgMCDgYurUYlFSkiu0ikH65Luv0VmOBoLNIiCGYg+SNMaPKck84pLJKuQMI9yMimkFn+F4AoFAQssAMYRgSKHgxbt1T2+X1l4XQsGgI4SAG+twOtpCHrObuKnRaFSUlZV5h5p51re++8OqJ59Z5OUWjHFcRdYMkFbLFNYM8OAIAisXHe1NKjMi5PnTxjhTz52IkuFFCIVCvYIC6OmOhRubm5z3Nm/Hlq070dnaojJzhwkZDJFiTghVYb1cAOB5GiQlwlnDxO8efYaLhuX+NzM/V1lZGe/vMk7eK19n9u+x0aisHQuQEeIAICXAXg86Wg+pCZOGy8svuwbTzj0n5ojgKgJndHZ1z3h385ZAXd1ytLQd1lk5I4SnDTdHKXOXiIwcEgLBcIYAETRLMCuAFAKSoOJd3NF2WJ87ZZycO3sGRo4o6i3Mz0csFkd9Y2N47/7DztKlq9DW1aoysouk51lPgrCWAGurpJh1I2Umr1y9EW8tW/dJAEsda8IwM+f++Bd/uvfJP7+is3KLBCwpREyWQ/Ank1GrSSm0NjeoomGZ8sY7Piznzztv2+SJ454vzM9/p7CwEEIIdl0XXR2t1NDUyk0tLXdu23Xg8lVrNmcuW74aLc2HPUmKfEd0Kii5Q4Z//ftnv//np19GOCNfEAUBpSyJbswMIcwikgJA3ENHW7OeNWO8vLrsQkyfNvnPMyaf+3ReYXbr+DF5S81dgG5tjQ9vau2Ys27D5kvWbNjyuZdfftNZt26Hl5NX5BAJGEPM1798fupIkULCJ3kHjjwYSCAxyC5yYy9LtjKNlTE/YFzL8Z5uHevtxMQJo+SsmRciJ9PpzcmJKOFItDTWqwUXzOSCvMz9ADC8pPjfvnzX55/RoOshAhSJhKmlpXmL26vWFw4fe1X1ky99+v5fPaZzcksEe5Qw9wDD+fT0xPTY0bniK3/38Q2Tx4/8YVtHK4QGAmRoeDWALqrslIpkhikrzLsrKytds16ktRd8s4YThmVSIgkISdDsWsVcGhNcxbmjq4mHFeSIubOniwnjSgDlxQIB6fX2dKqRI/JzRo0sDADA9On30IwZDWDm0H2/+vMvX3xpmRMK5SspHGLtJWgrYkAoB0QeHAnEerq057bRlZedL6+6Yn7rrGkTH5lx3oyVkVBwb8mw8EYAaOhwp7S3d03auPG9Gdu27P3ckiWrh9UtXo2e3m6dkVMgXKbkpuQ/awCsGOHMHNnSdMB7pXb5OTOmTvx2VVXVN2bMmCGPmOSDwiqN1hHCYEhHwIv3INbRzB/98HXy5luvfGvBgrkLJ48urA04cq/rKQIwcf2WAzdeetGcyod//1zhuk37dSS7UJjwMrJjNE+C/cnMBKUsOyHMGvJ6O5l0L33hM7fL665esOjcc6f89JwJw1b4o2toRUn9ofqb3nhz2VcffeL54tXv7NBZ2UWClYb2HRxgs05hTK9IMCJ37tiN7du3f5yZv+1UWhPm+ls+fdfSFesnNDR3e/lFI52YG4ckf+FYm40YglywjqO54ZBbVjo/8LGKD+279por/2fCyKyHiKhrsFtJwG808/BVmw5/ZOWqNf+yaNHicdXV1V5nZ4PH8Posaa21JCK14d29f7Nk2foFu/Y0q7zCcdLzXJDlM8yGaTgHSS443steTwfuuO0qcfvt1z113fXzv5dBtHSQ4RwC8A6AXzPzT+bPm/6dPzz2wi1//vNrOjNnpAACZme0BDNZLoBIQQgTjyRIWgpdQg5iH0rh3zuzCNm67En4bAdDswY0Q0CCKAACo73toBo9PE/edMPNmD793JfnzZ75xLzZo18A0IvkytV+aPv8+bPXAFgD4L7+Y2Dml159LXS7QxxhFWdO8ZOwJfqV261zs0pERkg8X3bxtF8P9gyPAQEAEp7hAchyQmyIa2OWGa3A3BHrDSGT6R7r7mApuujWG+fTRRfOXjtpwsRnp808570po7PeBNAJgPbub76q1+tYBwAjb8mminll3rKV735t8Zur5+/b1+rlFoxwlNIgcqBJW7PEaDkyEEBH2yFdkCPEpz5WgbIrL/vmdVed91siOjzAtRwCsNjev+9cfumCf7rwwqV//8gfnszZue+QyswtlgohqwmbeyhImat3Cfn5Jc5by9bpC+bM+npXnB/LDNKq6mqWSEgUQGu2io7/W4CEAz/7hBGAuZ8u4MWgeppUxUfKxF1f/Ny/X3rx5O+mxLP5WtR2APcy8xOZWTl//OFPfn3x1p0NOiOzSHhszDIG272AoElZESRBpCCJoePdLLmXP3bHte33/O1n7zl3Yv6jA2hoBwCsYeZHhw3L//H3f/LgzZs2H9JZWcOFMoQtiBmCdYJ+dwKCWlp61PYdB/J37G69zKkqLVPMXHTvr57457rXl+mcvAKhNIGEA7IuM2bHEJ+kAeWhs/2w97nP3Bb45Mdue+yaK2Z8g4j2AUA0GnVKS0vt2EphIkgMysrKFBEdAvALZv7z+edN/eawwuBXSoqLnO729gBgolxSPBE5D/3+mX95+ZU3dDicR1oLszMKZT0c1kUuGCrWzaq3Xd/9xU/Ij9158/cvOG/UN8xZo6K2tlSUlpb6ItgH1dXVibq6OhDRBmb+SHZO7s89N3738y+tVJHMIgmCdbsLK3Ss94IskQjjVRnMhQsAQhiCnRKT0yeJrEeJjDqtlQazC0cKtLXUqwvnTpKf+viH1t92c+n/HT2isHrQE9gDMbOoq6sTDQ0NfSbIxqIiCodCB7/0D9/dHwmFprJWmkmQ0bPMPWTWhsrXLtxYPFJbW+vU7YKD8fD8J1mHwVEKoKGhgSsqKiyZZ+aMUQF9cpHBpBOeKUo4IRiCge7OVp2bJcUXPlPe8+GbS6vmzZ7yv4MEiT4GJOaIx8y5P/rFY/9cW7eCM7MKBFgCTGaqCyNUJQk4AYGuzkY9YlSu+PJnP7zn0x//8BeGF2W/BhgzvqioKFH9ADC5b0VFRWTnRwuA/2TmX0+YMPzph377pxlvLl/vZeaOdhQ7Sd4ExiQ3jgsHECGuXbwc8y6Y/l/MfFtFRQ3Ky5PeTa37rmUSwgT2sY2XgmN8QqTQ3Fyv7vhwmfzSF+74z8sumfIdALK2ttYpLS31s74pGmWaMWOjQ0QHmPnOXXv3rP/Rzx7O8bweJhEmBc8Ie5aAZrDQgJ3LxApauehoP6zu/kKF8+UvfeKfp00q+EN5ebmsZkZ5ytqpBOiWVaskEW1n5o/XNzTs+d4Pfp3X3dutZSBDKDbmFbMGCRPbBQEQOThU30wH9tdPd0DgDVsOXrF+49aSppZWr2BYvuNZO9LEAfjeFA3JCm2dDaqi/Gbny3d9/CeXzpv6j0op1NayU1YKVUXkVVVVDTpBmZkq6+okER0E8LXNew8+1tnSfmEAzlsA/IsjALqlCxPeXrF2QkNjK3Jyx8DVxvVOLBMkKMEDPJd7u1r133z2Dvm5z97+tzOmFt1/110LA9csvEtXEKmysgFzuhJCyHjtKgDUfPml19c1MgL//udnXvfyCkc4nqfgB8Bywjtmv85squ3RMZLRSVhuwcboWA8ZWbud2DiHHUFoa96rFsybLv/xns8tKb/90huJqLO8vFz6ZQMqKyv7zFR/F7ILdMBIbmamv/+XnwilVSLYjjUbQeOnqpjPQUihy8rKvGi0FlWfL/MGf5JJpHwmeSMSGrLRqSBsPAop+PlcJp5AIx7r5XAwhn/46hd6vvDpj91SlE+vARDRaK1TWgqkXnddXZ2sKy3VdXV1AoC3YsPOLy1fsXF4a3uvl5tX5LhKmwBVX/sAQwLo7W7TeVmSvvSZ2/d8/asfu5qIti1cuDBw1113eYN4l1KTfqnOzNkdzFyWkRH5Kck/fGzxWxtVVu4I6Wr/+RqynaHheQqRrByxbu27vGrN2ls+etMlE2tqKrbX1FQPamYx27AG+HFVBIeAnu4ONXXKGPGhD5WuuOyS2d9LGXfqXOCqKmIA8YUrVwaIaO9Li9f++/x579xbW7dWZWWXSD90AjAhAtYvAsEMIRR6ulr13NlTnOuuW/D8jKnDfrVw4crAXXdd0P885lyAtufpfG9XyzffXrXpweo/vsp5BSPgac96vXyT2piiTiCA1tYWNDQdLhXMLNet2/yhZW+v53BGruXMyXIlACAhBMMRjPa2Q+qa0gXyi5++4+GL5kz6x//4j/8QzCzKysjDcdTrICKuMjV6qbq6Wp4zZsTyC847597zzptU779fU1NDAFBb9+bfrNu0gxkBz3+YxvXHgDZRm5IUOtoO6ZtvvEJ+rOLW/5kxtej+aG2t88ADd7sVx1mHxWhV1XrhwoWB666Y9e2brrvklXOnlDjdnQ0qIA0hm/TYJK1jP17haESyCT6zAWeJJ51CShMANrZ0T1ezPmdSifzS5z6ytvz2S28gos7a2lqnpqZGlZWVeVVVVZqIOPXneK4vIxLhhAPA7kKAhh8UB/Axr+NUQAPcJ9aAFADBYy/epj/36Q/jkxU331qUT69VV1cHAeiqqjKv/3WXlZV5VUS6rq5OM3No9er1n1yxZhOHMzIJgiGkAlMcTEmvHOteduMt/Ik7b6JP3XnHF4hoW3X1huDdd9/tHs899M9r3d8Nt94w/28/+6mPbBo/dpiM97Zoh0ywJ2kbKsI2eo0c0giqDRt30CtLNtwMABMnThxwh0pSGIk7ZMMFNDy3G9dfewXdcPXVlUTkHjgw9ajPPn/HDs3MdN1l59UumHc+JBRp5SaObmYCI9naTAM6zgHp0jVlF3bccs38LwOgAweeGaB2ThJ3XXCBF41GxTnj8h6Ze9459YUFGSIe79CJaU5mczUpMAJSOujpjaP+cENMAMjZtXPfR/fuPUzBcIb0oyqEpZ00AY4E4rFONW7McHnrjaXLrr1y1mei0ahjM0hPuGgPkUkira6ulv1rk1RUVDAzi81btl+zfcchimRkkR/DAbICgE3iYnd3mx4/dri86YbL3rzi4sn/Eo1GncrS0hMuk0FEnJ+fr4ko9ony6/7pphsuV6w7SKvexEJNkunGxBIkbDqAgDOI05/IhA6Q1XaE/0QgTGAd29wf5bJAnD9889WNt33kmi8QUVf/zPGTBsF4x+x4UmWLLwiEnRTidJTM7mPE2pP5vKXdzQ0/ptHZ2aRLr7xQ3njtpT8ePTz71YUrVwYqKiqOGp3OzGQrEuSu27D53AP1LRQIZgmlFbT2rGfOxqVAo7urVV+84Hx55ZXzfj56eOC1hQsXBioqZh71HAOBiFRtba1DRK3XXX3JZ2//yNWdWnUywTWxwJqM4GEPmjxoBsLhbHr3vd3YvevAHczs/PM/P8MpBzS/hOgrkElDKwVBQKy3U40aUyKnTJmwpKjAebG8ulr65T8GQ0VFhbLFwTaPHl78ysgRhUK5cUWJuBvjSGCbCiQFId7bpSZPHE0zpk97koj2VldXH7PqgxFIpYKIesaOHfWLCRPHoKe7WwurSYOFiVpmgEhAygA8pdDW1qHFngOd897dvDOjq9vTjhMmI2U5wWH4ufjxnm66tvQSfOjm6yuVUigtLcXx7rZHu0FlZWUJFc7WOtFx4PyDh5qmNDW3seOEJCfqaZoFSwywVoj1dPI1V1/CV19b+h9KKTpaFb/jGUttba0TCtGGSy6ad++FF5wvero7PSFtwqLvUSPA1w4Sqs+gabPmM/5nE8YZIRFdLEigq7NNLbhwjrzo4gt+k58VWr1w5crAaRE4CQhDfFuzRxhpCBBBChNpLQTB8XMpS0/+TBpInMd3z/sbBWyAKZFEPO5ydlZYXHXlgsNXXzG7sry8XN71zDPH3DDq6uokACxfteOL+/c3h9y445EIkNYJXRj+xqk8xaEA5JWXXdBz01VzqsBMBw4cOOlKhGVlZd7ChQsDRXnBlfPnnfPc3NlTZXdnqxJkWSrWIKuJK82QgZA4dKgJu/bunw+g6PXXqxLPVBAsH8jJIFBr8pgEPQ+9PV08c/oUzJo+7Y9EpO8pKjoudbS0tFQQkSoqyn179OgixOK9nAiitTlUZuM0yoXnxmnauZMwadK4JcxMRcd9HvOcx40aeWj4sGFQXtyGkTiGvxMCJI3DRQopurq6kZ2dfbHYuXPfVfUNLQFBQSZ2zA2wO5LQgBQSPT3detTIYjFr1uQ1Y4rDr5SXl8vTuygMrK2OVau2X3m4oVMyCyVkEEQm30XYoCMhBOI9vWr0qBI57dyJr44eFl5SXV0tjh79eWyUlpZqAHTFFXN+u+DC8z2wJ8HaxNII4bO2dhFxihgZ+LR+iFMqFWS8VzYamyRYExNYzp09vevWGy56MBqNigPPXHD6SnQyQHCspw/2Pppzg6wwgjg2N3W8kMKcigVAQbCQhkOAY3dao1l1dXSreRfMpukzpv6UiDqm33MP0XHUVKqznQDXv7tl/s6dBykYikBpk5RqnIU27YUYvd0davq0CZg5ffIPADRGK+vkqZbTzM/P18xM15Zefu9F889Tyu0UWsehJYNJgVjZ9BsGCUlxl9W+fY2BTdsaLk89TsLcYSQ0Dxs+CT9cJeAIMaKoUI8oyt8KGML+RMY6ekRxZnFxIZRnFDublWKePaR1Z5gY8nFjhruzz5vwFhGxXQfHgVIwM/LycrNGFBea8BrL2ZHwNxzD6QgSFHc9BIKBAnHwUH1Z/aEGBJwgMROgHShtKDg/piTe06tnzpiEOXNnPkNE+p577jkjBIDfWXL/3oP5Bw4cRjCYZaKh2YEgB5aWBAmBWDzOs2ZMwzlTpywmIm/jxuOTzkeDMRWjlJ8VWjNh3MjFo0eWkPZcJaXRBBJRo5oTLk9mDe9o4pft7pvYzSyHwgSChOu6XFJcSJOnjN4ZCgW3VFVVclUlTkmDPAIa0J5JeDRFAJIpLcwE1iZPyi+TcFR31TEgpa2fY7P7TXKtz+sIa1VoSOmJGdMmeZdeNruWmWmG8TAeFda0UswcaWpqPX//gcMIBgMicW8ZIM0g7YG0Cy/eTufPmoppM6ZsNYvp5K/Lh2++ZIbFktzcnMXFJUWit7dLwSbiCuHPUtgV7vDhwy1Uf6gpr8+1aPs++7mLhmeDTSFirVgKIYYNy6dJ4wvWAcDGjRuPa174wikUDr8aiWSAiIURxr5H0QHIeLA8rXROTrbIyojsDgKbgIRj4jjOY+ZpODO0SUhmEkIkOUOfRrbJvmz+Vp7HoqW1df7hhmbIQECwVmZ7ttngJsPBA8EVJcW5PGrUsMXmZMeeICeDqqoyo6WCr2toaEHACZEQATAb/sQvqSBIgJVHkyeNVbNnz1gMAJWVp2dMtbWlAmAaPWJE3dTJE9HT08Om7pJfI8jnR44t4xhIycaGzdyG5TSMIIv19uqpU8Zj/LiRS2KxOEVr6+TxkPInAgbs/fNfoZTfPtFz+vYRn+nyF5+JuBVWsye4Xi/n5WeJ8WOHt+QEsI6IuHwQ71sqLFfBAArbOrtLuntddoRMPgmbVmBKaGgOOEIWFuZ2TptQvAgA6uqOdwc/OmbMmEGsGdPOPad91IhixHq7jZaVKCzh3wiCFAE0NbahobExJ/UtTp0/nHgSNorKRGlLh1BYkNeZcgdOaJyZedmHMyIR+DOQYTVsWxsKwuhXTiCAvPw8RCLhE5p3Gzcar+Loosx1YOaA4wh/uvsiB0hGttuXSLS2tlEs5oIkoOHZGAqGMRlcaNXNAckiPy+HRxVmvZd6sjOF1rYOjsViZry21KgPIoLnac7IiMhI0GkfloXV9q3TMqHsWXjylAnNw0uKob24ybTxNRZ/Vvg4xp0wURepDG7C/wUpGFr30rgJozBh8vjXiYiPZ8c/4asRAkJI49q1nJTZWJLpq8ld8DSd02zfsGez6QICIIFYPK5GjizBmLGjVgLorq6ulsfDxZWWlgoAONjUvYCVynDduK2XwiC/8oIlkd14XOflZSMUdN6xcWTCLyJ1qvA5j+HDil4bVpgPz9SB8K/c/tZgVhAC1N3dDenI6/oexQhHwZQQzn5CshACrJXOzspCLO6uMeOPnvD4s0IZgUhGxLryfX42MSONOaQJUgYQCoZO8m4AAEKhcBiwlkDSUvcFjZ+3aUMzOjs74XmuIRdhgrhAyv54YO1BgJGfkwsAplzYCUrcE0VPTy+UUrYamU48Ej+rWSsNx5HIzc067ef27dkxw4vrHClARq2ydXpMIqKfc5WMRRgEbGNxfE8FJV3t0s6AYEiIjLDTPnVM0TIA2HhMMXbiYG2En08ia06WeuKUYMXTAs3Jvc5Pt2DfI2qC95T2kJ+XjeysrEVEpE/UNO7u6OGu7q6EyZpwA8NokABDs4dAkJCXn3lmYgEA5OXnNeZkZYO1Z+4pI+k21/b6ScPz4ujq6kq9waRtaRj02cSs+c6mFjWgEQwFT3r8jhNgx3HshuOnGlOC6Cdb+UGQQMAJnvR9AMBOwEmJzQKQDJhGYtNlYzoKrY0qZ73qJnyclYnjYLaVw5BSHuHMQ1lzSkCaHCXrPUoscQYEMYKh07cz90cgACUkGY8ETOSsryT48GNHB4NfJRBkY3Pt+iMGJAS0AiKhAIUCaAewFwAqz4DQIaGsgWO1GVsPydzbZJoCbHnwU/FemX2B7I6dLFJl0nNNdLfQLmVnBhEKO5tO5nxxpeB5HlgpK9StwGGzewsYD5IjJALOmWsgGArJQCgozUIyXAT8x+fXmGaGWU+qz2N1tafZJ49tJxBjfmpDgGhW1vXu+xSqTnyAAd9faFJyjAfTD9yjRDS1kHYanALIkFkAREJNMDW2+pcUA4S0tWt9rwyMFDIJiMwgYXbG1vZOABiwFvDphuMQhKQUtt1qCMLGu0gTD+HGYsDpJCNS0NLRO1wpD4lpbHegEzrbQNoQ+7uB8RKSIGRnZQrAJtucAQh/N/UT8kgBpE2FPNJml9ZsK+PhlIhkazgCiXo8/g8SiaZEQEZGBDmZkZPS6Z0QKOD4meOcuKc+Yc+2mqVmghs/7U7WBJQH7Slzz/x7l3RUsqUGGI6UkMFA6swZ5oSdgFIum2x/BWYFsJeiJRmt6VS2VQdIIe9t+EaCPfJHy3Z+nMwyqkz85af7+ELNhLXZwmj9mA+RkRGGlMKUF2CfRfcv2nzI073c1NJI+w51jwSAGTNqzpjKCgChkGO1QT8ehhN2KWuAJEGxRktbO+M0C8K6OvOcm1qaLveUhtaUKAWd4EOOE2bXt65q/6HaHCy/jooQBCcYOLEDnyBMJUBlhAv5mptxLcN6TZRW0OrUKY9kIVs/ENDa836kLgAwEAqFIG05x9ITPEdOVpbKyAgxSNk8H/jRCCafTTBkIICYq9HW0XPG1OHDTc1OW0cnKOAYXdFaA9qaEQSAtUIgIJGTlZ0Ig2jpwSUFBfmZsd5uZdwLnBCgRhc1gsFE35/8+LzEyhCJCezPx4QJTGZumE3w5M+VFGx2ipOv25iyM4bDMu+L7OxMz3EEtPLM/uSXHbXJa0I4pLRWLe0dVN/UNO9EgodOFtkZYS8UkFBKIbVcnE3MBwlJnT0x3dYRz2ztwrmASdI7PWevAwBs3rqb9x04BBlwbP2Y03nJ3Of3Gb2ZBDA8o7lCJzkH9guaKWitTAjAaaBZ2VZu9MvZos+Php/sGXAkZOjEdPpSG21ekpexNODInlDIcRjMvlrPEKbNDQHCCYjm5g70xOJzmHkSAG27pp4yfJf0oUOHrq1vaIATdMiUOUlWWia7a2utODcnC8z8vP/9/Ag2dbS290opBbMecKmfXn/iYLAOI59/OaUT+rW3U72kvkOK+3joRHZW1rLi4kK4blyZqEUg2e9IgCiAgJNF27YfwLubd8whIq70A2pOM6LRWlFdXS17untfzM/NgfY8PsKbSxIQDkgE9b79jaE1a7feAYBOR5wOAJSVlSlmFo0NTTdt374LgUCQTLW4Iz/rk3En1RHeClMjAE5zu+5+MJua1V79anVMYJXMF9JKwdOnaRyJa0rhvIhNt0ELKQeqdnxcBycA7TnZmXszsyLQZkfw2UtjzhJBSIc8T3j19S3hd97bewUAlJbWnRahs3HjRnYcic1btkzYf6AewWDIRMGQWXhJb5ThZkqKC3lkSX5C73ABh1iQnyXq86UEW0Yl5QinT/QMJsbsMzpFX4LwTbc+3G/qhpPy2THjx7xbPDwfrtsDQIMFIxn2T1CeQDiSQzt2HcS27XtuY+bCUkCn5kudDjAzzZjRICoqKtS5M6bHSkaOhk4EFWkzYW0MEQHIyMqhTdt3Y8PmrRcJIXjTjBOL1hxkDCIajRKAybv2HLzwQH0jpAxJYrbmp+n9ZPwjtkIMDZ575Udjwpb+BGAXhfUmQYMEIMSZIzuT3jPfa6WSaRkEsLQlN7WC8mKn/Ew97ZocKK0tR5F4B5qMsEt1p58IiIivjFZKIuopLMhdP3J4MTzX1ab1GtnWHwRoCcEBBEPZtHrtVuzYvu96Zj6i9MfJoLq6WlZVVfH+xs7rDze2Lqg/3KJCoRwB7cBoW2aRSSEBSSBoGjFiGI0cVXzIP0YA2NLR0d7rOAFhpohvlrAphGU5NqMbnjwn5QAmOdrfHH2vlQjApy/MzidOSeDYwcMk2foKC5Ao5Gb5LdgofjF2/JiXxowZqTQraDalF0wMh18cHAgEM0VXV8x7991thW+v3XlPVVWVfuCBVadtpVSbDF6uqKiIr3131x3LV77z9Z179nMgEpQ2tt26F82FaDCC4Yg8eKBeb9q46Yo9B1ourqmoULZQ0kmjrq5OVFVV6WdffftLS5evFq7HnhD2kJzCxfiku7VV4Q122uQun3jA5gUkHvZfQImWlPQgJEfA8IPpBBGUUujq7DnhRMj+8FNEmE3LFs0KSnmmk4hfK8bPATqJp1VZWgoAmDhh0sqJ48fDi8dgs3tsQz+/QoJAJJIrtm7fjTXr15UDGFlRUXHKJpbVqPmNN1bfs3TZegoGs9kUa/cXtFk/wnAyOjMSlqOGlxweWZK9KMF4A3IwnSP5D8thJl6Mnsqw+yIh8JPG4Jmx5wjJwMDkzBNTRuctnTplfG9GJCi1VuwHkZnfBCklPE3Izi6Qry1aot6oe/NrzDzp7rvnudXV1ae0yJmZotGoY1vMhJ9/ffXvfv7gozXf/8lDJbv2HkQgGKBE6L4llP0C35olZCCC2teXytcXL3+AmQMbN9bRyWpgfk3mWIxnrVi19p63V63XGZk5km3ogB1v4sfk2NiQb+coZokvmBIk9BH24skM9/hB1rPAPinpPzJLIjJDOpLaO7qQlZ1ziSlfW6pOdmCsRIIfSnqrrNnjewATnOWJTx8/jurKS2b8afTIItchLdn2JGMNW4HRKPtSBklzQNW9/rZ4+vnF3wXAI0c+cNJztra21qmqKvP2NvRctWz5O9evW7dNhSP5jin/YmIhfBNLSgk31qvHjxvNo0cOf4GI2u+66wF/o04xQvwNwW72fe66LxRODcbrmrLhcGpKxGna+PprSok+b0ZxARnKXMNoYA1TJ094c8zo4dfu3deqZWaWhLILIzFQAXLC1NMl8difXsgvKRn+IDPfSETx420e32c8ycJIHgBvV33XHff/9ul/f+KZRbPr3lilMrKHiWA4RKwFFPdV10x7EwGtNMKhbLF3/wHv6Rdfnzlm3LhvVVWV/Z8ZM6qDYHZPJJWAmUVpZSUxc/Zjf178qz/9+dUMxSEVDoSEVn6rldQba1RJ1h60adM5IEwwnnUdEoNgWqIb+WPdvIwU/ePMICCMe5lhAhx9zxlg3OkiEKCunji6enpHRiJh7u09xVCERE/ppDZltCybcU8p3rwTBJmWHgRg//RzJ+wuLsqe3NbVpUUwW7D2zQRpi6crhDNy5DvrdqhFb6z45KZtB56YPnnkExs2bAjOnHli5S2qmWWZ2RyDP//1nx948pmXQ044R0MEwMoKcDLXLsjUoIr3dohZMxbQ7DnnVAPAxz8+lR94wB5Q2LZGlNQGOPEfrMZ06gIh4YLXqRsnfNcqUkMaTuk8SB6f7GIxXkxKScEx5pZDRO6q9XsfWHDhBddt3vo0hzOLkm412y+IbFuJrNwiuWnLXu/hx54qyy/I+jMzf4SIeleuXBm44IIBq4z1QTQaFTbt3gPgMXP4tTfXRR948NF/fbTmeRw82OHl5Y1zWBKUjkNo22gNfoyM7aMMU1NYKyAzs1A+9VydV1Jc+PUt2w9snDpp5O/Lq6tltalpeVR/TD/hp18qve27j/3xxQs3btrr5RcNd5SyQV99767ZqcnvaaUGt7r925EohA27C/tBZGfetAKAcCgIKZASaGYgYLUg6VB3TxfXN7YU9/T0Tq6srNs1Y0YDD7SZmNKoEKWlGKTIU1KzM8pp8hGcrkJhtXV1ksrKepav2vqLC+ZM/8ELr76tMzNyhHYBVgTTGEqbrG8ihEIF4rHql3XRsGELu+K8JzNIKwepwHcE/DlSZsqjyt9Xv/KH3z78xKRDhztVZu4IqRRsPywvob0JIrjxblWQnyWmThmzefrUES8DoNKUWk9EtkUM9eNT2PeU9jdLTh5+rIyfu5gwefyOH3wazpOixJs/k8clX6jZ63Ki0aiYO3P0KzOnTdhXmJc1yov3aBnMsS23zETRgsAkEVeMrLyRzhvLNijmR2/wOLycmT9LRO8AgF9as6G0lMvtrfTLVZSVlemqqipdVVWlmblo3aYDX/3hzx//6KLFq6Yven2VcoLZlJ033GHAhICz6QhqNktbd5cdgBUglNnstARTkELhQvm7R55CRij48Loth4Pnn1P8EFX446mmhgZweXny0dYAVFRXRynCL+eFNzb89r4HHrnthZfeUoXDRjpKGeJaQ0GSsIKXAfLs4zES3LSNGaS0RcrfGtxX+SJLrg1eafS0ISMriGAQcGN2QtvdyPQfkwiwQzENtW7jtozXV2z9bFVV2X+ivFwuXLgwMHXqXXbQdX6d66MOWOtUhTBpxxOchJmanOgnh7q6Og0wzZ+LJxdcdH60dvGKLC8eZ4ggsfAsnSugtAmADAYiFOtR/NDvnx5GAfnSzv1NX5kwqvDRu+++OzlnTY1kBoCamhoqKiqi++67j225FI+Zz33sycW/++VDf75w/aZ9OidvuHRZmAaBrIyzwPaAF5LQ1t6Cm66/jC6/9LLfEZHXvzA7gETkNoS1O9g2tyPYTp18tFt9XEgEZfgd/bjPq30+eWpJB0c+U6tL24BBtiWcCA4AQUTtdW9t+M3FC87/jxdfW6HzI1nWc6RM+1/h2A3LgWJCdvZw+cZbG7zm9nvP27jpqpfWbDjw3dkzRjxGRAdramr6jyZx15h58uK33vvQz37xp39+e9W7Y2sXL0Nja6/KyR0hSYTgaQUSDLBMmCAkreKprB3KbHYzG/CkmeCITPK05nsX/kEfbm771VMvL7/p+mvmfytEtLbmKHGMzBzefajrkw88/Mw3H3/i5alLlqzV2TklErYmNDMndmc/AI0o+cgSk2ZQiER06UAPifw8rjOo8bBm5BfkUjgjgs5eDSGkjRM1qojpbEHIzCoQbyxerSeMGf7NTdsbumZPG/ndu2tqFHB3yoiBhsb4RS3tbZf1drU8OWvW1O3RaLRflTmrCgqrJSdeE6aNri0YdipaT1VVlY5GSx2isp2vvf7Ody+/ePZ3Xqpd7eUWjnRcV9k2W465ShbwNJCRlS8am5v0T+99pKCxoeUPL9SuueCG0tk/JKIDA8zZ5NUwD1u7seGe//nxY3//6GPPFW7edkDlFJRI1zOueSbP8GW2KLyQQCzervPyHXHBnCm7Lr948n3RaFSUl/eVHlJKSEfadAlKNDM0rYX9u8gDT53jhGcuAH3FizHrNEyba2GrHfTjD04Sqcfpqz0lth8iOJWVlQqAuPLiGf+9dPmsTy9ftXGsG+/UMpAhTM0YDdKuyVBOqGEOsgtKnA3v7da7dv26eN26zT9ccOGcf//TU8teHT9x7Prc3IztJSW56wFg976msgP79+ccOHDw2v/49oOXrtuwNfD2yg1oao57OXl5Iie3QIIdKE8nqunZQqkQguEpl5WOQUpJpo20UUnNP5S5p1rAcXKISNLvH3lWb9q45fZlS1fd+tiTr9dOnjy5rqAgb+OEkRnbYJhLvWHz4Tn7Dxyc+IuHnr5z7aZt0156dTEOHmhWuTkjpKtEimDhhGroeyd82/t4Fk3yI/0eAsHkpVib+jRHHyRQXV0t77zzTpWdk71s+PDhkw417NdB0zfTDiPFq0VBkjKPHv79s0Gl+P/96uFXbhkzZsRzJSX51NMb4/oDh0VbW9f13/7ujy6NRIJ0441XTgfwBaBUAKlCx3aDtVnsEPZ5JqS2fxtObYIbsjsqrrri/F+v2/DuPctWrBnh9nZoGcwQmi15aReTIIFY3EMonCd6Yp1878IavXrt5n9e9vbcL/zhj6+9OmXK5LXjx459c1geGgCguRl5u/btKt29+8C0H9z7x2uWvr2upPb1FYj1ks7JGy49pe08NJxVIrtEMALEaGpr4A999Apx/XWX/D0RtVZXsyTT4STxoIVwkvyWDaojUtY8sQEVGqc2Nzwk+DQ/Wjopgzjl58xse0b89PWbEggOEXE0WiuJqHfVur3f2bb94MLfP/qcl1cYFr5Ll6ASBBHZmiGe0sjMyhfK6+Y/PvWyeuGVNwqnTJxw5+RJE+7My82C40gwMzzlYf/BA9i2ZSf2H2hEXEsvIytf5hUNczQzXA0Qu5AkIElAsxE4jtSIdbdzKCAoMzeC5pZ2dpxsUlpA2PyhxOIn480ikYXs3KBYv3GvWr9huzN+7JhrZ8yYdm3hsHxkZUbgOAH09sbQ0d6BvfsOYeOmrTjc1K7CWXmUWzBGKtdE4JD1Qmg/JcSG7yf6NhGQiLclwiBeGEp6BnzV1k+K0/5BziitU1RURMyMKRMn1Y0aUfLJlWu2k1F11RFrXmsGiSAokItf/fZJ9eprSy+ZNXPKJcOK8+C5HuoPNmHH9t14d8Na76LL5uKGG6/ONt+s63McQdq6rpNZhIkQ+VT9/RRLBhER22qRh97ZcvCebdv3Pf3gb//s5Q4bSySYWBsHHCW4N9NdTYYyKCvoyGWr3lWr12zInzB6VPm06eeWDxuWj8zMCEBAT0cPmltb8N6WLdi+cw+6ul2VmTlchDPDIq48gPyi77ZVMUylPweMzpbDatrkUfKWG65aOXfmxOejURYDtRUWIiXbG8K2lbMbKhGE9CCkOIYmfWxwIjTC9CJjqGSslPVgGsF5qhMx4YMb3EyzrzsAUFVV5lVXV8u5s0Y/eOsNl5Vv37bnmrfXbPVy84qduEuANk3gIEwoPWDSJYyGkUn5hWEnHu/ljVv36bWbdjJYEYEksYCG8qQTQMgJUjijUEScgMMkobRpNCeltKamBrQpFC2lRmdHo8qMOPKTFdfHxo0b3XbvfQ8V7z9wWGdllwhlA/X8jGm2JSpN3RsHkcxiqZXHO/a06s3bXmcSLITvtiFBzKQcGeZQMEPk5o2SLABXmVQAR5jmYx4M609CJ7Qcn5NI5lH5D2pATsfzPK2ISGhtMnkTwodMEJUph6Csa/n04777TDDcnJljlo4sKfQcSdJklxszy098NvElNhfMCSEnOFIebOxSO19YxsqLm7IejoNIMESBjGHIyip0wP5FlyI1A9pxTPM8IgeCpKWVteUHTZ5XIk7neJteDgK/rvXsqSOeeeqpJT/dtnXv3y9astYtKB4R0Gx6qhP553KM9sWmUF1WVpHUbpy3727Sm7YsYoClEIJIELRm1tpVoUCQguEckZsXkcyOqbbgd3VlbXOMzFbsOIR4T5vODHviMx+7qe1jt19zBxlvFw3Ulcl4M32OzRLfdmMSQsKRATNn5KkJZ639nunmOfh1oXwfC7Hvazo1MCwFYd3zbJ0tSYsgyfkkAvzKy8s1EREzf3LfgaYX9x44NOfg4UaVmV0itWeS2AxZBpCfIEZkSmAKiUAok0KRHElI1hMxkpscWGlrymSQVb01/BR7c9EajmRIwWhpavBGjcx27r7rzthN11/2kemTRqxvazq8+Yc/ezjiuj2mqZcCQBK+o9HfSAm2SbwIUVZ2REpikwTIpiEGMwEkpbZzUSUeiImtIACeF4OUhEAkgFhvzOzaMKHeiSohVk0d4GH5L3W5ntsFEtmamcnXk9mQmxoCrIX/OM4IamoqfJV+07RzJ28eXpQ3vbmjWznBDKm12TjY73dNGkTKNoEjhMJZMiMj1woIDwwFCUKsN+YR2fIEA4CEgH3iVjP0M42FNZptyRTgVGUOAKC0tFSVl5fLW2+99J/bOroub2hsmrNh826vsGiUw9rW7LXCwch2ArED7RGECFNGdlhmZtvFkmRRiMh0mGQIKAUYoshy4KZYBAgC2lMIBAjx3jaOdTfj7r/7OG7/8LVfJKLdzCwG96D6vKT5TSRseQzf5LWf0qc6O0y+G9nGkQAsZcK2OnwyqfpUkCQPbPSzlUIkOKHRwfZYS9b4ImJLnB6+50u33P7Vv/14PC9Xyo72Q8qRluBNmBLWjQ2dCOlXmqEUw3MBzwOUFvCYjEajGSrBp5rvgzRgizdDajgOQ6t2bm3epS6/dKbzzX/44ntf/uKtc2ZMHvkCEe0rv+OmL3284lbu7mzRnhdjJ0DGxLLxEYZu4hRvkIbnuYh7HuKugusxYh7D1QxPmehrBRcKyozdM99x3U44MqZvubkM48eWwI3HbLsZOxUSAVx2kpJ/TX3uPwDkhYOBHM+NgaCJ2YNmD2APYJNkqbSyms4Zy73iyso6SUQ8/4Lzf3jxhTOpq+MwS6kBrQBltAG2AZh+drTWCsrz4MbjcN04XM+DUsrqK3475UFiO2y5Hg22icMmkFLY35q1aWnLHtRpkDpExNOnT2ci0p/+5HXX3vWlj62Zde44p+HQHhdawVQMCcBXrtimpBitWMBTBFcBHgOeNvOWtenx7THD08acIqEBoaCh4Xex1MxwnAC6O1t1rKeJP/vpW+nmW264c9KkkX+y7WqOosJafpCTgicZTOd7rZL1eU6mno4LNyFGfVbF/9Gw16C1DoeDaDjcUhuPuziVqH6yz97QriblRttiZImwF/SbOZbskkS0q/z2G2795tc+2zGqOCJbmvZ54B4IeGay9mOlJWSCaNYkbKcD/0eChQRspLNxGytLX2k4AnDgoavtsHLQSZ+88xr5T1/5+CN3ff7Gq3LC4Xdra2ud2tpaZ9rUUX8or7jpq3/z+dud7s6DOh5r1gGpjNbFtmiSTThOaNTke2mS4/F7eSnLqAkQBDMcB2DuQXfnAX377VeJL3zuNh0JEzzl2oWUFDb+vmDa12KwhE+ttbJuwmRmt2YFYwzav9n2Mz9DqKwsVcxMc88f8/BVZRdtmjC60Il1NqmAnRRmSpoSFz5JD/judIKQElI6gJQQ5MBxgiDIwe12WzFPIJl1bex8nxOEFXCn75ptGAaIqOnuz9987df/6Qtrrrz0/EDzoX2uinWytEXMfDcAYJ6iXyoFLEAsIUQAImWuQguQDTj0I6n9Rq+SAAEXzY37vHCgR/zt3R+jT37ytjsvXzClZuHChcdsIZQwO+yxU7tOC6sppKaOnlwahAez4H3t0tfjYLU2hlYumDU62zsamRkbN9adlGolrRYDYdNQiE1ROEqWyvGf/RHLhYhUNBoVo0qyXuphPt8RgT9V//H5OW8uW6UjWcMQzsg1hdnASE0BF0z9ZGnKjQWMemprwIIZDhPAHno6O5RyO2ju7Gnylhsu3/ehG0q/ef7MsY8CydQEAFi4cGXgmstn3rf07S3doTD9+rHqZ9HWdsjLzClxIALwlPE0mcWQYraQBoSAToQCG1Fj3lK2GR4Q623Vsd4m/sLnPiLvrLj+21lhVsWFeZWs2CNIJ1Fj1hhg8F3dggZPMk8ESGlDHJqgUBOukcwmNpP7TMFqsIKI3B7mD+/ft2/993/y62CcpQ4G84Ty2Lh9fVXfxlQQkGhva0xqkeCwNAA9aEkGtsX8jWbjl+w0EMZc0ARoiZNKvhr8OrW9ziZmviYvN/fh4cOf/dDTz7+Ozp5WlZmTJ6UMwPMYIAc6JQEX8H04ychpJpGYPyQsfwgYgUpArKdTd3Y06OnTJjgfr7hp/4dvvuYfZ04b+ceFCxcG7r777uOo8eQHUZrj+RUq/XZACo4lq0/hpriAIdQVUpUuP4nacPkexXq7UDK8cIGpslh30mf0W0URJCRxojRuwsQDA6x5wPVSVVWla2trnQjRTma+dtyY4b+Z9OcRN7/6+grsP7RbZWfnkgxmCkEO/KTQxIpO2QIFpcRjaPs3a7COc3d3h3bdHpo+dby87uqbcNWVlzxyw7Vz/oWI9peXV8vq6nJNKX2s7r57nhuNRsWCeZN/s3nn4diEsSX//cSfX53w9uotmmSmjmRkSyECiVvrd6UyVpH1NlgXpSQkWhNrL8bt7W2qoCDgfPnzn8ZHbrvmF5dccM5/rXxn57+Gg5IFu8YutQ4nMxElJBMcYcupDvYMoC3/ZWxqP7qZjBQyfaRx5mvBEpGuZpYRom1r1m3/m47u3t8vfPBx9PbEvcycYQ7LpLAmn5+HJRltwisJtpyWRtyLabAeuNIhsybyPX5Gi0pExMKzPJwGMVieWhjKgNcZjUYFETUDuGnpmq1fmjx59P++8OLi3DXrNrN0wiorJ0+CTJs5FgQWfjSjbR5NANgxz1XC8BJggBS01hzv7dbdHa0oGZYvP3rrzeL66y9fdOdHSj9HRHttV9bjKiqnOc4EF0KYRWn4Vy8hoEm4AAt4xu4/SbislMfE2pi4trCWebYMMt43cr04IpHgZMdxcAp9wTSRFoL8WvmcEOQkTPgLiBEMBmjQTPEy079ZEFETgFu27mi7de6Ftd95Y8myGW8uW4VD9fXKcSIcDIbJCUQESMKRgkgkd23jKQCYNau4x/F4r/bcTgo4Wp43Y4pcMP98XDR/9qs3XnfF9/Ky6VXAaDcVFRVqIFdhVVWVrq6uludMKH6UmZ8ZP378fy9Ztubvl7y1VqzfsBWeR0oGgiydoJAyQCQcksKqxjY0XnmKXaWgPFe5ve0UCrC8unS+c8P1l++46abSb0wek/MEEBWZkUzJXpx6Wg4pJyAprnzbVADsIEBArLlRxbq65CAhgl5vb6dqbz/MTq9LEEFb3MqEHZAAPC/GAdlDrL1Tqop9PKiwbXHnnDfpkTXv7kduTs6Df3j0mcjW7Xt1IJzFoXCmkDJIhjQnkM2DZlZQnscMzT3xmO7paFAFeTOdQFAeBIDSUiDVO6O0F25rbVbtLb2qJ9wNpfyqcRJMcRAxVNthz3U7Q0qd/uu2phZVVFSIi+dMeZCZXzlv1oyf1dUtvfmt5WuczVt3Ie46yglksQwEhBOSJEwxbCQSU2EK+rH2WHkx7ca72Yt3k5AsR40skhd96HosmDd7a1nZJT+bPWPkzz7mKVRXsywro+OtQ0GsY8G2tsMq5rmsdYBMTXCCIA0IRjzerYQrQbo3bK/shO+FEhQAXHLbm9x2KaWynJEfkAhixGIdKjOQ6cTjsZ5TMHkFa9dpbdmvIm4vMwRpbVkkhom3c7sZmaCuzpaWo5an8AOaKisracrE3KeZ+YWLL5r5b6vXXHLHho27Z77zzkYcONSA1rZOxF2F3m6lEvavVQ1JEjIyIzInN0zFRSXi3HMvwtRJY7tnnjv5mUsvu+SXRfn0qtllo4K5kukYXTr9HuhE1AngHxo7ep699JL1d61evenmrdv2hLdu24FDh5vQ1dWFnq64SvATdlyhYFCGQiGMGD3MmXbObMw9b2rb/PlzH7zy4mnfJ6L62tpap7S0VO3Zc/ixaeeO++anP1eREwgFzC4otOE8OAAJRqy7VV68YCZywk4cvhKUDALbPGrU8C3/9I93TevsdCFlCIo1oG2nS+nCdTuQlRHE+FGjduEM1Cjqj7KyMi9aW+vMmTbqkY4YvzNpwrgf172+4ppVqzZi7/5D6OhoYWbjLzFOHw0hNDIiEZmVmUXjpowRF8y+xpm/YPqm8SOGf8/ODQ0A5eXlVFNTg3FjRmy950ufvGDfwSbpOEEozzofWEJDQZAHVj1y+rQJsfycrNUAyM8cP12w+VQqGq11iGgXgFvqm7svq619665339t+647dh3Lf27wT9Ydb0N3Tg3hPnF3X1eRXJxcMSVKEQyHKzY3IomFjMHH8aEyeNCY29Zxxy2bNnPKn888d9ysi6gZA0WiUBorFGQjRaFQAiJ0/c/K+b3zti1OVBogdsDacmanvzGDulYX5GZg8ZdRWc3+rqaam4riu32/Kl5UTrJ83d1rj175xzzBQEIC0z9UzZjQTvHinHFGSi/yCjKdisTiiUZNJfzznqaoC2zl7aMqkkau/8bUvzPU8gnQiVnNm6x1juF4M+bkBFBflvHbckzw1m5yZg7v3dV276d13Lz3c0HTh4fr6WY2NTXmaZKi3pxfKVscPhcLIzs2GDFDLmFHFh3Oys58995xzlkyfXLKJiLbYQ1N1dbU4mUz1ipoaUZMc0znr3jtwwZYt265vaGi8qKGhsTjuqrzOrl7E43FoZuRk54AIvaNHj2gpKip8bcqk8U9fMGvsCjsxE9dockWJN28+MI1FeGpLeysTKZIJCkKCAc7JyKBg2D00YfToVUAyAdL//p49B2cGg5mTGlvaWWmHFGxGuiMhoeBxjPOzsykS9JaOGDHisP+9E7kPJ4PUZ7lrX8/V69a/+zdbt24uPVjfMLyzoxtdXV1QmhEKOcgvyEFGRqR54qRJhwsLCp+dee7kNyaOzXmNiLpTx+v/zcyZOw/UX9PREYMjHcT6FEZ3IJk5Oz+D3M6uQ+ecM2b5mb5mc/xK8qOmmXnc+s3752/dueP65obWi+oPNhW1trYWMwO9PT0QQiKYEYEjJXJzcg8X5OdtHj6yeMeEMWNfOm9GyWop5Wa/CHu0ttapOsH22n7aSGNj12gRDF7Q2tLKgCSlLMMlHSh4kA4QksDIkvxX+t/r479u4s5OHtHZ483v6OhgwCFI4zWUkIACZMiBA7d3zMiCOiKKAQk/yQmdh5nz9hxouTIei0Miw16Mh0RchCMhNLxxo/PfPNGdlaqrj4ywZOYMAKMOHm6bpJQSsZiCdCRCIQehUAYKcpwVAFpsgiUAoLy8WpaXG83lBMfQB9XV1bKmBqipSR6HmR0A+c3tsQu7u2KImfrPXDS8gDIdbAZwgIh6Uo9h45Q45Rh/EQHwfsFO/kRICDNnNDf3zIkpkdvS3MBKeZQRykRGhsSIEQXLAbSmaqGn4/78Je8xM4uamhpKnW9sGm+H29vd8yED+e0tzQwAGTk5RMQd+dmBVY4ju1XfgvVUXc2ivBz6gz4//mL31yYRH/fHT+YczEw1gNhYWUe2FfBxqcfRaNQpLS1FaWmpPnoMw0mNSdTV1Ym6ujpUVVUdc/cpL6+W0+8pItTV6cHIs+QxAZQe+X4pTJHuwQSn/33/33X9vusftrS0dJAyEWceAwntwRCN1jozKku5HIMvOL8UhP/vugE+U4qj37cziWg0KlBaKnCc8wQARaO1csaMUi4vxzHLpZzIOEpLS0VpaSnX1Q3upj7VudH/eQyEhtJSrvBbNpzB85Sa7rWnZ92bgFsWzCwH+Tnpin6nMB4aaCzRKIu/5FiGCpiZqqurJTPL6mr78z49v78U/Ovyrzv1x7521l1zGmmkkUYaaaSRRhpppJFGGmmkkUYaaaSRRhpppPFBwiAetg+kN8v3vtkI1jROAf5zx0mGiBznOSgaNRURUr2n6ef3142jTrhoNHrahQ+bhj+nfMwPolBMI4n080njCPiTIhbjmezyda0dfG1HB1/LzNcx8/nMHPY/eyZ2phOZlP5nmTnsunwdM4890WOkYeDfsy1bdk3fvb/xutTnfBrhP6/MV15b8t26xSt/aDUr0ePydQcOHBiXOpY0Bi8Fc9bAtj7Wy5atu+2BB3//x1279sq4Mn22HSkR6+2O5xcU1j/550VLb/tw2T8S0cHTFOIvAEQAxInouModAEBlZSURgZ9++vlfv754yccmT5q4l5nnAWg421MzTjNMJRXmyMIHfvdcdyw+fta0aZ8C8IgtQXFCOVODnSMajVLlVyqz7rvvd88+/+KiK8KZmdi8ZffE7KwsXrd29W1zzp/2FoBLKysrTyin6WzGWS90ioqKiIj41bqV1z313MvyzaUrY6Vll4XCoQg8TyEeiwWXLFsz5pnnXxyzv/5AGTNfTkRbamtrnTqbIpESsp5I3+gf9u2Hq9tyILxp255pTz7xZG0oIFu7urqueu655w6m5nfZnY/8NAn/+1VVVUxE6Ojqmfvyq4uQmZk1JhbDsHCYDtsdFDU1NaKoqIjs9447pSQ1LcM2l0tNZyBOFp7vszgGy01LHf+JpjWkjqW0rlRTlX8NTNXVNaL/+VLHAvTN2Us9Vl1dqa6qIh2NRqmqijTAw7ds3pazfMVKVXDX5yPmM4PnJfmabv/UmCizKE0+K01Eura2VpaVlXkVFZ8p37J16xWZWRk4Z/p0vLLojQ/v3LYNE8aPxMUXX7AcAGbMmJHQdJhZVFbWCaAONi3ofUuDSeMMoLa21gGA195Y/aOyGz+jP/KJf9CrNuz/+ZqNByveXLHz40uWbv/UU8+//caNt3yez5lVxr//40uvStnHwjrC3BrMBItGoyIaNSXplr/zztTLy27jik9+mZl5pHnfjGXw77Pw33trxZpLH3/y2YeeeualbzJzlh+uP8hlHo/qPuBnrEZ2QjjaOI5lRvjC6ni+e6L/ToHwx8jMU/7j3/+n9cabP8l/qHnmC4DJuzvaGFOPfbTx+udYu3bL6KeeefGl51+s/Sozn/vzXz6+6hv/5zt7Xnxl8feYOasfXzjgmI9yT886nPWajg8BIqVcys3NxOhRhbUl+eE/+u8x8x+8WO8TX//mf9y6fPnqOZ6ncrq6kCEEghkZtIeZJx+ob5nf1d7+ztSp4zfZQlHFmzbvKW1oaHJGjhwVmzKxuJaImhcuvCXAzOJgkzdLOJk67jm6vgVfaznc+Wh+cdZqqwlpyy9MWbt274xI0IlPnTaijoiao8yCKyuJiN5k5iYA24nIZVOYSjFz/r5DnbP37zswPCczC9OmjVxLRJsGu+5EF2GAmfncdRt3zemOxfncqVMb8rLwJhH12nsgARQAaCOiuL9IiIjb29svlVLuzMzMPGA1BMXMkTgwZeWytdNBRHPmnrcvI0iL+5So7QdfuxBEUFrPXL16y0zXVbRgwbQ1RPSerTgXBHAJgMU2q90fOxERH2w4eFVPR48zceLEl4mIHSnhet6cdRu3nysBzJgxaQURbauosLVnXIwIhyK5cdeDZlOFLxotl9XVXCClbLBlKohNjWVm5ok9PT0uEe1N1YaY+dy3lr87JxiUmDdn6gYpxfqUMij7mPlmAJPfXvXeRaWXX/7o9C9WvEq23bb9jL2dxFrrmSvWbLmlo6Nz7tgxI6snTxj+NBHFjuyWenbir0bo+JUo47E4Otvac59/fksoEtkfaGgoAhF1P/XUW38YXlLy4Y729gwAV/3wJz/7edxFpPrJ19/55Ge+Oj/g0P9v77ujqrrS9p99zrmFJh1EFMFKkdgVURRsSYxGNEJ0kjFGY0mcxGTiJDoZBVJ1kqixjb3EfmlGKfYLUelNkWpBinSkXrjtnPf7AzBMEvPN+v2+7/dby+Rd6y4W55y97z7vOfu9u7zP85hNnzY5jTE2PiEh860NId98nV+Yb9UthTNyxLDHVxMyVk3zHxNuoCPn0zPuvlheUUfVdc38++99vLa3reyDK5cSNjLGvqyoqBt6+PuzZ69cUg8UGC/T67QYPnpEfXJa/soJjEWFErEf4q7+K/TLXav69nY8R0SBjDFKyrgdvOmbf+1KScqwMzWxhE6ngXN/B+MPMde+f/mlgFUARMae8G8CAJMkYjKZTDodGbfnw3WfLq2sqpcJfKd0j6/PuHsZ2UUfjRk5NDoq+vyB3Nw7QZ4e7tcFQXgxNDSBDwsLMBYUFL+yc+eBCK6zE44BUJ+envvnbdv2b8jIynQBJ8i1Oj0sLM0QfvbShQVzZywNDQ2tAf59itLd8YjI4kxE7J533/skuKGuRTAaAKWJoDt5Ku76ooUvvnY+7sp3N64nLXTp53KdiF4KDQ3V+Pv78wDEwnsPJx48cOIqx4yoqSkbrFT248/Hx3//xtI1o4wGgwAA5mam2thY9aVZs/zfYozVAWCd8kkSFDKFHQDcuhX9hSqi5O09B87sWv7mgnXbt2+XM8Z0KSlZi/6x4YsjNrY2GiIaw4ASIuqjOnf18JLlH01pamxWEBlhZ2OpV0XFJ82a+/xixlhFWtqtl/fs+X5nRkZ2v5aWDrRptOjt5NgaFX35yrzA6UsZY80qlYoLCgqS4i4nH1vzt88X5uUVCgajCFsbswV+vhOK8/JKPvbycjtLvylb82zY7yboGGGEwSCCMR6CIG+bNWuIDoCu+7zBqH2lubWRREksBNBRVFzWJ/6SGsOHDwsQYIDH0EGSidIsLjm1aOmB/Yf2X7h0HgHTAtDf1Q0Fhfewfce/bGpr6k+XVbbUxMREG21srXiFUinqDQYmlwlwcHDk9UaxHxFZbNqy6/LRIyf7DRv2HAa7Dy2vqarqd+z4abvy6qrwO3dKXmKMXTh26tzY48ejKGj+S86MMaqqqh+3ZeeuMyePh2OKnz96O9qXdejMnM+eixFqa5qW2lo53p80yevLnsxvXQqY4pUf0zYePHh0ZWHhA8x68YVWuQyN2Vk5LvsPHBokV+Bfpqam0WVl1W4q1Xmzha/KB/E8j4SEUABAQ3O7X+wFNbm59O2NTj0X7uq1q0fOqKKZl/cwuLq6lhslsr6svmpeVVX/gsDxW8LCwhb1nC50/8oTEX/4WHTU0e9PTFcq5BjpPbzMoINlSlqa5fad+6Z3GMSTnu79M6+pE8i1/yC/Cb5+C8LCwg4DrvKAAGY8eTJuhUoVSwH+4+scHPqZ7doTEbn34P6BNpameG6Yp0an1+vTM7Ot75WUvtym61AxxgIgQ1WHVtsMwFKplLsBQHl55cDwyHNm7/5l9WIAYWvWrNECQFNLh8uVazflQwYPkOv1sGJKjo6eOrdvz77DMzXNbZg8aZKeY5KUlpasZJzkb2Nl8RERrd2169AP27fvhpOTM3zG+0AiCRcvX7N49KhintFgkBHRXMaYGB2nPrp375HXs7JyMPulF+Hs5IzU9GR8/e22Ia0trRGPa9pGM8Zu9yRZexbtdxN0AAGMV8AoCRAhG/6wqlmjkCkGNDe3GkofVgw9cuTQKx26djZx4vgaAEWCTEY6rY4m+Y6v+1PQnBB3974ZAAo+/3J3aWxcPK3925qyRa8v2Ghta/2opUlntWPnnu+PHT5h6ukx5PDqtxf71TaK0fcflB/lOIYvNm1cZ9dLkWbRS6Y+EXHpVGR0fL8Jfj7az0I3LnbtYxtuMBg9/rn14NHvj4ePHeDWfwsRXd2xPyrKqd/A0eDkOsaAx22NGgc7G+07q5fnv/6n1ze5D3YOb2/vGNZva79TB/cf97yTlx9MRJsZg9gl4UDBwcGiiYkJcu/ceSMpNVMMC/nswRsLp0+SyWS1N2/mvnY799aXFhamP+r1epiaW+itbe1JoTTT9vQax8k6rKwcmFkvC33XIXJwdEhctuxN2bQXpv9zuPuAczqdznTM+LG7P/74H6/fTE6eQUQOjLEnTIgbN14TGGPGG0m3lkZG/zDdwrKXNiRk3d8mjvHeqdPpbFNSiz9fuy5kWVR0/LTn9225OPeVwMzTJ8+PzLqV+zoRHQOgCw1d4rxhw7cvWVhYsykBM3akZuSPib9wdaCNtRV9+UXILt+xnt8B0F69nrlt/fqwwPCoH/yz8opmMsYuvfPuhhpTpYll/aPqdADgZbzexNyc5CYm3QmDnboIxPSm5tZkZmEJuRy1GdkPXtj0zdaX2lpbpa++CD07+3nfEADipSs3FlRVlge1adriABjNLMziV7+70svDw3PfpLET1Sa9gFERIz9Z//dPn//xetLsoKAXneubNc5fbf5ucUpquvT3jz/MWbZ86Se9FNDfK53v/c2W7duOHDvDu7kO2slxnF9QUNAfI51nwSTGw8zCEomJN40fr9u4Xi6ToJTLodMTiorvorT0Hla985bo6+PzfkV1i6No0GH4iGHczJlTjnh49NsLADdSsgNuJifb+AdMoXmBczf0sbM51l3/ncJKl5z03G+TklIHzA+cbgWYxwucETK5DAJnSDcxUaqJyGT1B19ONxhkFBS8OMXe3vJ+clb+rMJ7ZcL06dPSzsVcHV1QeM8DQB+DEW0icTAYSeI5Dl6DB+cRUV8ACgCGwsKHAzqA5n79+2usrG25hobH1kAX23a3fisRIxMlKeRyPUlgaWnp5sO8hr5nMBhOCAJ/QhSlE11THhiNRoiixHie65Jn9AeQCCKOM/4k98G6hv4BRGQDgL+RkjPlftljd1O5GVlZ2PJGA2wBDABQGx4ezgEQgQSJiPj9h8Nfr6xsoPf/uqZ8jPeQi+W1zQM7OqD3GT/kwIIFC5YcO3FciIuN5fymBBxLTMgYk56aOXXxgsBhCnOWc/PmrcDsW7dshw0bop83Z2rUV//c9VlVVSUtXrKwzHes50fdTJBEFPynV18tUEWdGZySnPIez3OXeI7niCQwhaAAAKOBIBPkTKPRFAHQr1ixQti3b5/BaDQyoyiyLnEdWUFh8eI7uQX0cuALmtnP+65ljJV0Pe7P5HL5Z3p9dxzGLMYBpiamaGvTOAEw+vgFXBvmHfdiU4uOqqs7JmbdzhiRlJRKc2bPomXLF39ia84udJW9FhmbOD4t9fbClLTMcaIoujPGCp/ladbvJuhwEMFxgCQZIPA8SDKgtbUZPCdggs8ovLXstXujR3n95Tl358LKyhYPvVZLvczNmN5obFCr1UJdXR21t+umNrW2cZ4eHk1u/R1i1Wq1YG9vz+Xn54teQ53O2Njaf/WwvERWUd9m7+3ipBWNOjAGaNuMVkTEt3RgpE5vNC+rqKLduw9PPHPaJFPgAHMTczS3tKOgoIiGDh6AsorHLxhFo56RBElirFOLmnrFxl9flZh4c3VjY4OTqakcvWytkFvwALU1dZDJhF+8oKrwcC5YqxMn+/puerCg7Ehk5Hmnkgd3P+nfz2H9rj3HC0ePHrF5zEiP04wxPQFMJMAgAlqtjvn7hwIAJPBMlKQuTbPOUUFadt7rX32z8+viwge9lUpT2DrYora6AQ8elNP0qdNhMOBJXlLXaEcKDQ2VNzd1DNW0Ert44cfB2dlpxdq2VoLEmCAzQUHhPampsZ6Bk+ZMGee9SDXY7eus9FuyxKTU5UT04YGjZ9fU1jdi2jS/mwCKDUZpMsdzzMbW5jJjrCNEpZLPGTCAGGOG8/FJ58xNzNfev1s6xGgU/f+x4Zs+OoMeRJwR6NKLlAgyGW8BgCsqKurk2WZMYoxDFwWyWUVV1WCZ0oTxPH+TMVayYsUK2d69e8XQ0FAuLCxM7Ob2JiLTuIvJSzMzMz/84MMQV4MkQmsQkJaeY3wl8EXB3FzO7uQVGTVtWubcp0+zjZmQriLi+yYnyy9evKhzH+xxpX8/t0VlpWXyipoGKwAIDQ3tlC95Bu13E3TkHA+tphV+vj58WOi6febmin3a1haBV5oYXZwsGYACxpime8uaEwRw0EHOMcGvK5HsckKKIxiRIBMAgK+rqyMAUlBQEACASCSeOCYDcyR5R4nRYIRSYQ49GTwBRHdoWuzkCkHJcUwc6j5ENsDNCTWVlWUC8U02dg7cRx/9dUA/Z9sKE4Wg5sgwh4x6CDwnSBLhqjrz/ZjYC2GZGZmYPfslEOkrLSwtmwYPHOJ8N7/U0mD45RJAV4fgGGNHk1NvsUEDB6xPTc8cUvroEZdzO9/z+s20o6/MnxsskwmzJdaptq7Xt0sKhZJWrlzBO6xWUYeuXQcAvEzOA2jJzS+deepMxLGY8xfw/MwZ6N3bPt/EXN7o0s/FIj0z11uv62CQ/fq2sAhAZ9BCEo16O1tHudbUhElGIxgEeHt7YdoMf7j0dakCUDF+7NjspBtp45IzMufPmDE+4UZy6mAHx97iuHE+BwGIndJjIoRO4SggLw8POpP1OJlcWSNTKNDW3mYAYMXL5aZ6gwGOve1nADgISBBFI0yUij4AFKtXr9asXr2aNzM1n6Y3GiAoOiW9BJ7jtFodzMytBhCRRXBweDtjoJCQUAkIo7y8PCIi8xOn465GRMSMA5Pg6toHrv1c0NYhQiYAjBMhNwHpxU75Io6TAwAhPBw6+7FdOru8nDEGrU5Pkk4wdvNXP6u7Wb+boANIkEQD5AKYgqMrfezNMn9+xd69GbKVK8cY3n33Q/ACA+NEcD2VLBldlcnY8qbmZos2LUYEBwdf9gwKkucHBOhz8x/OaqivVVhb92LWdo53mnXNHIkiiRIxo54aurZjUzs6NA19ejvYzA98Mdl3pNsSAI8YYxoAIKJRAG4xxsRtO0+ZSqIISRRFpVKB9Ix0/4QfE40rVyy/9f5f3ngLQCljrDEq9mZUalLmPK22vcfL+VOf7x6iTxg//IhMJjvSqNePysu7/1xaavbbW7fsGKkwVb6k1xuGb9l9vF2nM8AgwZTjgB07duiwYwcWX04dVltXh6GD3HgA+tzcvKCIiHNSYODLbZs//2ugQqFQ6/V6lNa0LY46G3NUr29DTxU+xhh1BXLRzs70vomZ0dFvyqiyd5YumNushU4BMKUSIoCBADQ8zydLkoQ7xY+2Ozn3PpF9K8/uembJlqyc2/T8NH9x4gTvywCYQsZnd+jaAxoaH08lIpOeRPvHVePmt7Q0S9aW7mUASs3MTCCKEhjj7QFAEHgCCG3tbVq5XNZiMHQmJ0fHJto1tTRCoVQCQLtr/773STSOaKhvGAygT3h4cFFQUIg8LCxMT0SujLGHc+e/9kL0DzHjHtVWi5+GrjsyadK4reZydJTXday9cSN5lU6rg0Yjylxc+sh4nqP6+gbLpjaMDA4OvoouqQQ///mBJQ/u0oQJo5idkyUXFhYmKZUKhPUUFHuG7HeDgCWCxHEAYyIkGM1UKhV/584duUqlesKHW1k5+slwQRCIlEoOgsA9ydidPtkndfzYUe0XLl3A8ROnPiWi8XkqlVDfqJkfEXV2Y17ebTZx0rgqWyeLBmhhbm5uxkpLSyVNR0sAETnKFfKa8WNG5be3NrLjR4+MLKlqDEan3pW1Oun2ts1b952Kioo50DklgcTzDEZJJEHgYWVt6cwYcTzP5AAeymSyxrJHNc8nJCb43btXCFMz+S8S57o+VqfPREaePBUZrdfrvc0Zyxo/bNCRaTOmZ7oOcuOra6ukivp66/7O/ZtIhFSQf98tNbPkEyIam5xV/M9z52LmFBcXQyaXcQDAGIiXgbVr2zgAHQDQ2EajDu878EFGegaZmpoSDD9L9/f35xhj4tAh/U+5utiziDMn+19LyH7HUgkLpRLK0ora0d/tOrx/6459ux41NLgCgNfgPim+vuM67t19yG/e/G1fOxtr8vUdewWdqhTSyOHDE/v0dmQRUVGD0rOLzxJRXyKyzS8q3xwdGTXB1qoXN2WK3xUAD1ubm+qUCiVI6oSj9OvfVy5JRLeycy1rGzpeIaJxGbeLN0T/cN6z8lGl1KuXJQHQeQ0ZcnzKZF8uKiLCeC4u8TQR9QkPD9MnpeSE7Nh98NaxY6pNksisKqurYW1txVz6uhaay/HgcYfBMTIifMqtnBwSZHLS6gz1PhN8I8eMHc5i4s6y6PM/fEZEk4ho7MOylmWRkVEzm5vr2JhxI4pNZbgVE3t16669R+7EXry6CejMhv4f7xD/H+13M9KRyGjS1tps1Fqbc4wJQnBwsKhWq/9NkiQk5ElCHKfVanhtR6vEy6AAgMOHDysYYw/V19MO1NQ+fu+bb7f53L33IMXWxubevbvFgy7EXcacOS/Cx2fsOxaM1RARGzVyeOOVawnWX3z+edCokV5TDh9VJby2MHD1o9KKnENHjigb6uo/GzbM+y0GXvjx+k1njaYZ7779hsAYo517VIzjecg4JrS1tcN9yJCvfcaN2b9vzz7v9jZN8fbdB+o+/ewr97LyBk6p5ME4sYda5k9wBiIyKysrn3/p4jUk3UydtWXLvvuSIMg2/iNk4P2799gHH7wj9bWzK9B7j949e9asN7Zt3yG1tLZ97ubW//OyslI0NbdCqVRKGk0rA6D08BxyeubMqcvPnIk0B5H6221HHvx9/cbBJSVlMoNeFCWReMj+/b0K9fcXvVQqftL4sQcDX567+OC+Y+NCQ79YfXXyhNW9e9sgL68Aly9fxbI333C1kJlaAWAcxz2Ijr1+MC7u2l9iw493fPDxOhPfMaM+Z4zpQ0JCuBnTJu4qul/y7tbtu+z++rePZk729blFYLrc3Dynxw11WLJkccHz03z3A+Ae19fqWpqbxG6Yh/dw75OT/HzmnzoTbiGJFOHm1hf5BXdRW/cYCpnCYNBqZXo9HN3dnWOen+EfXlyUH7RhQ+iI4ruvpYRHXU7ZuXNvUGFRIT5e+8Gk50YOipjiN1F78NAxZdinX33tMXTQ2pr6KsfSh9WQDIBG0yqKovh4qItd2qmI2OiSh8XzNm3+akJx0d3rjnb2SFBfR3paJt5avhi+E8a9B8Ch8G7R+xs2bETIxn94EdFuxljZs7Sw/MwHna51F5iZylLnzp6xCoyDQsbfBjoxNL9WhjFD2/Dh3hoZx5lZKBWZAODq6mrsggx8xIhrsbOxWZeXXyRAlAZxJGHlyqV6/4DJyyf6PHdWpVLJGWPVKTey3uzoaD2VnJphkp2V72Bn7zQPwJIFr8wJtLYx35mUlOSSmZ7an+M4OPW2xrSAedcnTfJdFqJWC4qSdpGBAzGDged5+E8efVSn75jay9RiUWpqmr3S3MzextaaVq16OamoMM/X3t62Dj9l7qJzU4o4xtijhISkVxm4zbm5Ba6ZGbc99EYJgpzHmtUra6YGTN7IGKthjNUk3szZRJx+XWZmDkpLSuDm5qoPDJx7NzUt2Ush49oAKEYMG3TtckLqGjNT0+/y8guVlZVVnrY21nj9z6/ljRk7wsvJ3sYAoAkAgoKCOre9OqdYFBwcrKura15sKjffevGK+oWs7NuMMRFyOY8Vy5e1+U30WW5ursjZu3evbOXKlUZPjyGH5syautzLc6DJiOFeCY6OvbJCQkI4Ly8vxhhrKK+unmNiIj9w5XKCV1bOHRsGCTY2llj06rxrf1o473XGWAsR9fd+ztPcybk3r1BQDAB4e7hGXrh2c6vSTPFB3p1C1NbXoK9TH03w/Pm52dlZPra2FtVyOcqDg4OZSqVaCcnInY0+/8qhQyf6iUbqZ2GqwMqlS8tmTAl4W85YbmJixktygUXm3M63ysnLcexlYYqFwa+m+vn6elv2Upgy0WABIrYQWGSikO+Jjb/w54z0VJ6MHKwsrbB27XsVAVOnrPf2GHCRiBwszEwzl7+5ZLSluVk8gOouffZnIuD8XuwJhiY///5bWVkFC7r//7WLu4+XVFZ6VFTUT3/atUQ0OiWjYO3ZH67syskpXkVEw4GfMDTdC9JaLQ1NTs55+1pi+srU7DsjerTH8l7Jo3nR0XEr4uOvraysbZglCD/Bb74/Ef/NuCmLaN2GLdeFTiwYx3Ec9HoaExOXsCImLmFFY5tuFGMMlXVNY6qqWh1+ra3d7SAii5LyyllxcddXnDoVsyKvsGwZEdl1neN6tMsjKT1nVVJ63ioi8iQiobSi7uXiknKfzvsjHgA0ehqblH57VcQPcSuK7z+cTUTCvYflUx88KB/+Gz5jACAIAjR68km8kbMqPCp+VfatoiVE5Pzz5wUAVVWtw6prWxdRp4DizzFRICJ5RVVT0OWrKduu/Ziyv/RRzUyO47q/jwOAsrJq74qq2oVEZEJErNsnzRr9+MzbxatupGauIiJPxoD7Dx+9VlLyyL2n7ziOoba2ffI3332f+v5H3xpiLqamEpEl8BO2j4hcMrMLViYmpa8sra6fLgg8qh+3PnfvYfnUn/ujSaMfo05MWRsZGb+huLjiTSKy+lldJhqtYQ79RMXxBy3G79kYY08F5/0cyElPmYv/FmCyrKxmUEFB+Zq16zfVD/CaLO3efyaNAQgKCvo/Bnt2g1D/u7b8p1xC/zecQ79V9lf8998Qrz31vtjPg9OvXfNbx3qU5wAg/uKNJTm5VZf3HIgxvP/Xrx6fVp1f370e+JR2/GrQfdr99wCo/hFgniXropL8j9C8ISHE/Rbyl4g4tVotqFQqvqvepyLH1eonNJZcj/JMpSK+m+Jy7969MgDs0KFTycFBb5FL/2HSex+EUuL1nGXAv72Uv6iP/gPKVepCqavVaqEnrebT7qu7fvpJtPAXAVWtVgshXT7orv9pfviZsSflf6MtPb/nt0am1CWO1/35T+v4NV92tqnLryFP/Ou+dcs+muwXSO6efvopAYF04MCJKKBTtbbr75O6ej6rp7UnRK0WQkJCfvXee/j8jwD0h/3vWfcvYIQqNvLv6780bN68venShRuf9Dz3h/2/tR47gBZR4bHx6z8ONa77+6fiiZPhaSWFJe6/NXL5w55u/wX6Qt/AZobTjQAAAABJRU5ErkJggg==";
const CartromLogo = ({height=40, dark=false}) => (
  <img
    src={LOGO_SRC}
    alt="Cartrom Embalagens"
    style={{
      height: height,
      width: "auto",
      objectFit: "contain",
      display: "block",
    }}
  />
);

/* ─── SHARED STYLES ─────────────────────────────────────────── */
const font = "'Barlow', sans-serif";
const inp  = err => ({
  width:"100%",boxSizing:"border-box",background:C.white,
  border:`1.5px solid ${err?"#D32F2F":C.line}`,borderRadius:10,
  padding:"12px 14px",fontSize:14,color:C.text,outline:"none",fontFamily:font,
});
const cardBox = {
  background:C.white,border:`1px solid ${C.line}`,borderRadius:14,
  padding:"16px",marginBottom:12,boxShadow:"0 1px 4px rgba(11,37,69,0.06)",
};
const headerGrad = `linear-gradient(135deg, ${C.navy} 0%, #253C80 100%)`;

function SecLabel({t,small}){
  return <div style={{color:small?C.gray:C.navy,fontSize:11,fontWeight:800,letterSpacing:2,textTransform:"uppercase",marginBottom:small?10:12,marginTop:small?0:22,paddingBottom:small?0:8,borderBottom:small?"none":`2px solid ${C.green}`}}>{t}</div>;
}
function FWrap({label,err,children}){
  return <div style={{marginBottom:14}}><label style={{display:"block",fontSize:11,color:C.gray,fontWeight:700,letterSpacing:1.2,textTransform:"uppercase",marginBottom:6}}>{label}</label>{children}{err&&<p style={{color:"#D32F2F",fontSize:12,margin:"4px 0 0"}}>{err}</p>}</div>;
}
function DRow({k,v,vc,last}){
  return <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:last?"none":`1px solid ${C.line}`}}><span style={{fontSize:13,color:C.gray,fontWeight:600}}>{k}</span><span style={{fontSize:13,color:vc||C.text,fontWeight:700,textAlign:"right",maxWidth:"65%"}}>{v}</span></div>;
}

/* ─── APP ───────────────────────────────────────────────────── */
export default function CartromApp(){
  const[view,setView]=useState("list");
  const[projetos,setProjetos]=useState(SEED);
  const[form,setForm]=useState(BLANK);
  const[editId,setEditId]=useState(null);
  const[detailId,setDetailId]=useState(null);
  const[search,setSearch]=useState("");
  const[errors,setErrors]=useState({});
  const[filt,setFilt]=useState("Todas");
  const fileRef=useRef();
  const fichaRef=useRef();
  const detail=projetos.find(p=>p.id===detailId);

  const filtered=projetos.filter(p=>{
    const q=search.toLowerCase();
    return(p.cliente.toLowerCase().includes(q)||p.modelo.toLowerCase().includes(q)||p.segmento?.toLowerCase().includes(q))&&(filt==="Todas"||p.linha===filt);
  });

  const sf=(k,v)=>setForm(f=>({...f,[k]:v}));

  function validate(){
    const e={};
    if(!form.cliente.trim())e.cliente="Campo obrigatório";
    if(!form.linha)e.linha="Selecione a linha";
    if(!form.modelo)e.modelo="Selecione o modelo";
    if(!form.comprimento||+form.comprimento<=0)e.comprimento="Inválido";
    if(!form.largura||+form.largura<=0)e.largura="Inválido";
    if(!form.altura||+form.altura<=0)e.altura="Inválido";
    setErrors(e);return Object.keys(e).length===0;
  }
  function save(){
    if(!validate())return;
    if(editId)setProjetos(p=>p.map(x=>x.id===editId?{...x,...form}:x));
    else setProjetos(p=>[...p,{...form,id:Date.now(),criadoEm:new Date().toISOString().split("T")[0]}]);
    setForm(BLANK);setEditId(null);setView("list");
  }
  function edit(p){setForm({...p});setEditId(p.id);setErrors({});setView("form");}
  function del(id){setProjetos(p=>p.filter(x=>x.id!==id));setView("list");}
  function openNew(){setForm(BLANK);setEditId(null);setErrors({});setView("form");}
  function addPhotos(e){
    Promise.all(Array.from(e.target.files).map(f=>new Promise(res=>{
      const r=new FileReader();r.onload=ev=>res({name:f.name,src:ev.target.result});r.readAsDataURL(f);
    }))).then(imgs=>sf("fotos",[...form.fotos,...imgs]));
  }

  /* ── LIST ── */
  if(view==="list") return(
    <div style={{fontFamily:font,background:C.off,minHeight:"100vh",maxWidth:480,margin:"0 auto",paddingBottom:90}}>
      <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&family=Barlow+Condensed:wght@700;900&display=swap" rel="stylesheet"/>

      <div style={{background:`linear-gradient(135deg, ${C.navy} 0%, #243E7A 100%)`,padding:"0 20px"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",paddingTop:20,paddingBottom:14}}>
          <div style={{background:"#FFFFFF", borderRadius:12, padding:"6px 14px", display:"inline-flex", alignItems:"center"}}>
            <CartromLogo height={36}/>
          </div>
          <div style={{background:"rgba(255,255,255,0.15)",borderRadius:20,padding:"5px 14px",fontSize:12,color:C.white,fontWeight:700}}>{projetos.length} projetos</div>
        </div>

        <div style={{position:"relative",marginBottom:14}}>
          <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:C.gray}}><SearchIcon/></span>
          <input style={{...inp(false),paddingLeft:38,background:"rgba(255,255,255,0.95)",border:"none"}} placeholder="Buscar cliente, modelo ou segmento…" value={search} onChange={e=>setSearch(e.target.value)}/>
        </div>

        <div style={{display:"flex",gap:8,overflowX:"auto",paddingBottom:16,scrollbarWidth:"none"}}>
          {["Todas",...LINHAS].map(l=>{
            const active=filt===l;
            return <button key={l} onClick={()=>setFilt(l)} style={{flexShrink:0,background:active?C.green:"rgba(255,255,255,0.12)",color:active?C.white:"rgba(255,255,255,0.75)",border:`1px solid ${active?C.green:"rgba(255,255,255,0.2)"}`,borderRadius:20,padding:"5px 14px",fontSize:12,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap",fontFamily:font}}>{l==="Todas"?"Todas":l.replace("Linha ","")}</button>;
          })}
        </div>
      </div>

      <div style={{padding:"16px 16px 0"}}>
        {filtered.length===0?(
          <div style={{textAlign:"center",paddingTop:80}}>
            <div style={{fontSize:48,marginBottom:12}}>📦</div>
            <p style={{color:C.text,fontWeight:700,fontSize:16,margin:0}}>Nenhum projeto encontrado</p>
            <p style={{color:C.gray,fontSize:13,marginTop:6}}>Toque em + para cadastrar</p>
          </div>
        ):filtered.map(p=>{
          const lc=LC[p.linha]||C.blue;
          const lb=LB[p.linha]||C.blueXL;
          return(
            <div key={p.id} onClick={()=>{setDetailId(p.id);setView("detail");}}
              style={{...cardBox,cursor:"pointer",overflow:"hidden",position:"relative"}}>
              <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${lc},${C.navy})`}}/>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                <div>
                  <div style={{color:C.navy,fontWeight:800,fontSize:15}}>{p.cliente}</div>
                  <div style={{color:C.gray,fontSize:12,marginTop:1}}>{p.segmento}</div>
                </div>
                <span style={{background:lb,color:lc,borderRadius:6,padding:"3px 10px",fontSize:11,fontWeight:700,whiteSpace:"nowrap",marginLeft:8}}>{p.linha.replace("Linha ","")}</span>
              </div>
              <div style={{color:C.soft,fontSize:12,marginBottom:10}}>{p.modelo}</div>
              <div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"center"}}>
                {[["C",p.comprimento],["L",p.largura],["A",p.altura]].map(([k,v])=>(
                  <span key={k} style={{background:C.navyXL,color:C.navy,borderRadius:6,padding:"3px 9px",fontSize:12,fontWeight:700}}>{k} {v}mm</span>
                ))}
                {p.onda&&<span style={{background:C.greenXL,color:C.green,borderRadius:6,padding:"3px 9px",fontSize:11,fontWeight:600}}>{p.onda}</span>}
                {p.fotos?.length>0&&<span style={{color:C.gray,fontSize:11,marginLeft:2}}>📷 {p.fotos.length}</span>}
              </div>
              <div style={{color:C.grayL,fontSize:11,marginTop:10,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span>{p.criadoEm}</span>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  {p.fichaStatus==="aprovada"&&<span style={{background:"#E8F5E9",color:C.green,borderRadius:6,padding:"2px 8px",fontSize:10,fontWeight:700}}>✅ Aprovada</span>}
                  {p.fichaStatus==="reprovada"&&<span style={{background:"#FFEBEE",color:"#C62828",borderRadius:6,padding:"2px 8px",fontSize:10,fontWeight:700}}>❌ Reprovada</span>}
                  <span style={{color:C.blue}}><ChevIcon/></span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <button onClick={openNew} style={{position:"fixed",bottom:28,right:20,width:60,height:60,background:`linear-gradient(135deg,${C.green},${C.greenL})`,border:"none",borderRadius:"50%",color:C.white,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",boxShadow:`0 6px 20px ${C.green}66`,zIndex:99}}>
        <PlusIcon/>
      </button>
    </div>
  );

  /* ── FORM ── */
  if(view==="form") return(
    <div style={{fontFamily:font,background:C.off,minHeight:"100vh",maxWidth:480,margin:"0 auto",paddingBottom:100}}>
      <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&family=Barlow+Condensed:wght@700;900&display=swap" rel="stylesheet"/>

      <div style={{background:`linear-gradient(135deg, ${C.navy} 0%, #243E7A 100%)`,padding:"14px 20px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{display:"flex",alignItems:"center",gap:14}}>
          <button onClick={()=>setView("list")} style={{background:"none",border:"none",color:C.white,cursor:"pointer",padding:0,display:"flex"}}><BackIcon/></button>
          <div>
            <div style={{color:C.white,fontFamily:"'Barlow Condensed',sans-serif",fontSize:20,fontWeight:900,letterSpacing:0.5}}>{editId?"EDITAR PROJETO":"NOVO PROJETO"}</div>
            <div style={{color:"rgba(255,255,255,0.55)",fontSize:10,letterSpacing:2,textTransform:"uppercase"}}>Ficha Técnica</div>
          </div>
        </div>
        <div style={{background:"#FFFFFF",borderRadius:10,padding:"4px 10px",display:"inline-flex",alignItems:"center"}}>
          <CartromLogo height={28}/>
        </div>
      </div>

      <div style={{padding:"4px 16px 20px"}}>
        <SecLabel t="01 — Identificação"/>

        <FWrap label="Nome do Cliente" err={errors.cliente}>
          <input style={inp(errors.cliente)} placeholder="Ex: Renault do Brasil" value={form.cliente} onChange={e=>sf("cliente",e.target.value)}/>
        </FWrap>

        <FWrap label="Segmento de Mercado">
          <select style={{...inp(false),appearance:"none"}} value={form.segmento} onChange={e=>sf("segmento",e.target.value)}>
            <option value="">Selecione o segmento…</option>
            {SEGS.map(s=><option key={s}>{s}</option>)}
          </select>
        </FWrap>

        <SecLabel t="02 — Produto Cartrom"/>

        <FWrap label="Linha de Produto" err={errors.linha}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            {LINHAS.map(l=>{
              const active=form.linha===l;
              const lc=LC[l];const lb=LB[l];
              return <button key={l} onClick={()=>{sf("linha",l);sf("modelo","");}} style={{background:active?lb:C.white,border:`1.5px solid ${active?lc:C.line}`,borderRadius:10,padding:"11px 12px",color:active?lc:C.gray,fontWeight:700,fontSize:13,cursor:"pointer",textAlign:"left",fontFamily:font,boxShadow:active?`0 2px 8px ${lc}33`:"none"}}>{l}</button>;
            })}
          </div>
          {errors.linha&&<p style={{color:"#D32F2F",fontSize:12,margin:"4px 0 0"}}>{errors.linha}</p>}
        </FWrap>

        {form.linha&&(
          <FWrap label="Modelo de Caixa (FEFCO)" err={errors.modelo}>
            <select style={{...inp(errors.modelo),appearance:"none"}} value={form.modelo} onChange={e=>sf("modelo",e.target.value)}>
              <option value="">Selecione o modelo FEFCO…</option>
              {FEFCO.map(g=>(
                <optgroup key={g.grupo} label={g.grupo}>
                  {g.modelos.map(m=><option key={m} value={m}>{m}</option>)}
                </optgroup>
              ))}
            </select>
          </FWrap>
        )}

        <FWrap label="Tipo de Onda">
          <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
            {ONDAS.map(o=>{
              const active=form.onda===o;
              return <button key={o} onClick={()=>sf("onda",active?"":o)} style={{background:active?C.navy:C.white,border:`1.5px solid ${active?C.navy:C.line}`,borderRadius:8,padding:"6px 12px",color:active?C.white:C.soft,fontWeight:600,fontSize:12,cursor:"pointer",fontFamily:font}}>{o}</button>;
            })}
          </div>
        </FWrap>

        <SecLabel t="03 — Medidas Internas (mm)"/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:4}}>
          {[["comprimento","Comprimento",errors.comprimento],["largura","Largura",errors.largura],["altura","Altura",errors.altura]].map(([k,ph,err])=>(
            <div key={k}>
              <label style={{fontSize:10,color:C.gray,fontWeight:700,letterSpacing:1,textTransform:"uppercase",display:"block",marginBottom:5}}>{ph}</label>
              <input type="number" style={inp(err)} placeholder="0" value={form[k]} onChange={e=>sf(k,e.target.value)}/>
              {err&&<p style={{color:"#D32F2F",fontSize:11,margin:"3px 0 0"}}>{err}</p>}
            </div>
          ))}
        </div>

        <FWrap label="Tamanho da Aba (mm)">
          <input type="number" style={inp(false)} placeholder="Ex: 40" value={form.aba||""} onChange={e=>sf("aba",e.target.value)}/>
        </FWrap>

        <SecLabel t="04 — Impressão e Cores"/>

        <FWrap label="Cores de Impressão">
          <input style={inp(false)} placeholder="Ex: 2 cores — azul e branco, Pantone 485 C" value={form.cores||""} onChange={e=>sf("cores",e.target.value)}/>
        </FWrap>

        <SecLabel t="05 — Observações Técnicas"/>
        <textarea style={{...inp(false),resize:"vertical",minHeight:90,lineHeight:1.6,marginBottom:4}} placeholder="Gramatura, acabamento, reforços, requisitos especiais…" value={form.observacoes} onChange={e=>sf("observacoes",e.target.value)}/>

        <SecLabel t="06 — Registro Fotográfico"/>
        {form.fotos.length>0&&(
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:10}}>
            {form.fotos.map((f,i)=>(
              <div key={i} style={{position:"relative",borderRadius:10,overflow:"hidden",aspectRatio:"1",background:C.grayXL}}>
                <img src={f.src} alt={f.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                <button onClick={()=>sf("fotos",form.fotos.filter((_,j)=>j!==i))} style={{position:"absolute",top:4,right:4,background:"rgba(11,37,69,0.75)",color:C.white,border:"none",borderRadius:"50%",width:24,height:24,fontSize:13,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
              </div>
            ))}
          </div>
        )}
        <button onClick={()=>fileRef.current.click()} style={{width:"100%",background:C.white,border:`1.5px dashed ${C.green}`,borderRadius:10,padding:"14px",color:C.green,fontWeight:700,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8,fontFamily:font}}>
          <CamIcon/> Adicionar Foto
        </button>
        <SecLabel t="07 — Ficha Técnica"/>

        {/* Upload da ficha */}
        <div style={{marginBottom:14}}>
          <label style={{display:"block",fontSize:11,color:C.gray,fontWeight:700,letterSpacing:1.2,textTransform:"uppercase",marginBottom:6}}>Anexar Ficha Técnica</label>
          {form.fichaTecnica?(
            <div style={{background:C.blueXL,border:`1.5px solid ${C.blue}`,borderRadius:10,padding:"12px 14px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <span style={{fontSize:22}}>📄</span>
                <div>
                  <div style={{color:C.navy,fontWeight:700,fontSize:13}}>{form.fichaTecnica.name}</div>
                  <div style={{color:C.gray,fontSize:11}}>{(form.fichaTecnica.size/1024).toFixed(0)} KB</div>
                </div>
              </div>
              <button onClick={()=>sf("fichaTecnica",null)} style={{background:"none",border:"none",color:C.gray,cursor:"pointer",fontSize:18,padding:4}}>✕</button>
            </div>
          ):(
            <button onClick={()=>fichaRef.current.click()} style={{width:"100%",background:C.white,border:`1.5px dashed ${C.blue}`,borderRadius:10,padding:"14px",color:C.blue,fontWeight:700,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8,fontFamily:font}}>
              📄 Anexar Ficha Técnica (PDF / imagem)
            </button>
          )}
          <input ref={fichaRef} type="file" accept=".pdf,image/*" style={{display:"none"}} onChange={e=>{if(e.target.files[0])sf("fichaTecnica",e.target.files[0]);}}/>
        </div>

        {/* Status da ficha */}
        <div style={{marginBottom:14}}>
          <label style={{display:"block",fontSize:11,color:C.gray,fontWeight:700,letterSpacing:1.2,textTransform:"uppercase",marginBottom:6}}>Status da Ficha</label>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
            {[
              {v:"",label:"Pendente",icon:"🕐",bg:C.grayXL,fg:C.gray,border:C.line},
              {v:"aprovada",label:"Aprovada",icon:"✅",bg:"#E8F5E9",fg:C.green,border:C.green},
              {v:"reprovada",label:"Reprovada",icon:"❌",bg:"#FFEBEE",fg:"#C62828",border:"#EF9A9A"},
            ].map(op=>{
              const active=form.fichaStatus===op.v;
              return(
                <button key={op.v} onClick={()=>{sf("fichaStatus",op.v);if(op.v!=="reprovada")sf("fichaReprovacaoMotivo","");}} style={{background:active?op.bg:C.white,border:`1.5px solid ${active?op.border:C.line}`,borderRadius:10,padding:"10px 6px",cursor:"pointer",fontFamily:font,display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
                  <span style={{fontSize:18}}>{op.icon}</span>
                  <span style={{fontSize:11,fontWeight:700,color:active?op.fg:C.gray}}>{op.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Motivo de reprovação — aparece só se reprovada */}
        {form.fichaStatus==="reprovada"&&(
          <div style={{marginBottom:14}}>
            <label style={{display:"block",fontSize:11,color:"#C62828",fontWeight:700,letterSpacing:1.2,textTransform:"uppercase",marginBottom:6}}>Motivo da Reprovação</label>
            <textarea
              style={{...inp(false),resize:"vertical",minHeight:90,lineHeight:1.6,border:"1.5px solid #EF9A9A",background:"#FFEBEE",color:"#7B1A1A"}}
              placeholder="Descreva o motivo da reprovação da ficha técnica…"
              value={form.fichaReprovacaoMotivo||""}
              onChange={e=>sf("fichaReprovacaoMotivo",e.target.value)}
            />
          </div>
        )}

      </div>

      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:480,padding:"12px 16px",background:`linear-gradient(to top,${C.off} 70%,transparent)`,boxSizing:"border-box"}}>
        <button onClick={save} style={{width:"100%",background:headerGrad,color:C.white,border:"none",borderRadius:12,padding:"16px",fontSize:15,fontWeight:800,cursor:"pointer",letterSpacing:0.5,fontFamily:font,boxShadow:`0 4px 16px ${C.navy}55`}}>
          {editId?"SALVAR ALTERAÇÕES":"CADASTRAR PROJETO"}
        </button>
      </div>
    </div>
  );

  /* ── DETAIL ── */
  if(view==="detail"&&detail){
    const lc=LC[detail.linha]||C.blue;
    const lb=LB[detail.linha]||C.blueXL;
    return(
      <div style={{fontFamily:font,background:C.off,minHeight:"100vh",maxWidth:480,margin:"0 auto",paddingBottom:40}}>
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&family=Barlow+Condensed:wght@700;900&display=swap" rel="stylesheet"/>

        <div style={{background:`linear-gradient(135deg, ${C.navy} 0%, #243E7A 100%)`,padding:"14px 20px"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
            <div style={{display:"flex",alignItems:"center",gap:14}}>
              <button onClick={()=>setView("list")} style={{background:"none",border:"none",color:C.white,cursor:"pointer",padding:0,display:"flex"}}><BackIcon/></button>
              <div>
                <div style={{color:C.white,fontFamily:"'Barlow Condensed',sans-serif",fontSize:20,fontWeight:900}}>FICHA TÉCNICA</div>
                <div style={{color:"rgba(255,255,255,0.55)",fontSize:10,letterSpacing:2,textTransform:"uppercase"}}>Detalhes do Projeto</div>
              </div>
            </div>
            <div style={{background:"#FFFFFF",borderRadius:10,padding:"4px 10px",display:"inline-flex",alignItems:"center"}}>
              <CartromLogo height={28}/>
            </div>
          </div>
          <span style={{background:lb,color:lc,borderRadius:8,padding:"5px 12px",fontSize:11,fontWeight:700}}>{detail.linha.replace("Linha ","")}</span>
        </div>

        <div style={{padding:"20px 16px"}}>
          <div style={{...cardBox,borderTop:`3px solid ${lc}`}}>
            <div style={{color:C.gray,fontSize:10,fontWeight:700,letterSpacing:2,textTransform:"uppercase",marginBottom:4}}>Cliente</div>
            <div style={{color:C.navy,fontWeight:900,fontSize:22,fontFamily:"'Barlow Condensed',sans-serif"}}>{detail.cliente}</div>
            {detail.segmento&&<div style={{color:C.gray,fontSize:13,marginTop:4}}>{detail.segmento}</div>}
          </div>

          <div style={cardBox}>
            <SecLabel t="Produto" small/>
            <DRow k="Linha" v={detail.linha} vc={lc}/>
            <DRow k="Modelo" v={detail.modelo}/>
            {detail.onda&&<DRow k="Tipo de Onda" v={detail.onda} last/>}
          </div>

          <div style={cardBox}>
            <SecLabel t="Medidas Internas" small/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom: detail.aba?10:0}}>
              {[["Comp.",detail.comprimento],["Larg.",detail.largura],["Alt.",detail.altura]].map(([k,v])=>(
                <div key={k} style={{background:C.navyXL,borderRadius:10,padding:"12px 8px",textAlign:"center"}}>
                  <div style={{color:C.gray,fontSize:10,fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:4}}>{k}</div>
                  <div style={{color:C.navy,fontWeight:900,fontSize:22,fontFamily:"'Barlow Condensed',sans-serif"}}>{v}</div>
                  <div style={{color:C.gray,fontSize:10,fontWeight:600}}>mm</div>
                </div>
              ))}
            </div>
            {detail.aba&&<DRow k="Tamanho da Aba" v={`${detail.aba} mm`} last/>}
          </div>

          {detail.cores&&(
            <div style={cardBox}>
              <SecLabel t="Impressão e Cores" small/>
              <p style={{color:C.soft,fontSize:14,lineHeight:1.6,margin:0}}>{detail.cores}</p>
            </div>
          )}

          {detail.observacoes&&(
            <div style={cardBox}>
              <SecLabel t="Observações Técnicas" small/>
              <p style={{color:C.soft,fontSize:14,lineHeight:1.7,margin:0}}>{detail.observacoes}</p>
            </div>
          )}

          {detail.fotos?.length>0&&(
            <div style={cardBox}>
              <SecLabel t={`Fotos (${detail.fotos.length})`} small/>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                {detail.fotos.map((f,i)=>(
                  <div key={i} style={{borderRadius:10,overflow:"hidden",aspectRatio:"1",background:C.grayXL}}>
                    <img src={f.src} alt={f.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Ficha Técnica */}
          {(detail.fichaTecnica||detail.fichaStatus)&&(()=>{
            const statusMap={
              aprovada:{label:"Aprovada",icon:"✅",bg:"#E8F5E9",fg:C.green,border:C.green},
              reprovada:{label:"Reprovada",icon:"❌",bg:"#FFEBEE",fg:"#C62828",border:"#EF9A9A"},
              "":        {label:"Pendente",icon:"🕐",bg:C.grayXL,fg:C.gray,border:C.line},
            };
            const st=statusMap[detail.fichaStatus||""];
            return(
              <div style={cardBox}>
                <SecLabel t="Ficha Técnica" small/>
                {detail.fichaTecnica&&(
                  <div style={{background:C.blueXL,borderRadius:10,padding:"11px 14px",display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                    <span style={{fontSize:22}}>📄</span>
                    <div>
                      <div style={{color:C.navy,fontWeight:700,fontSize:13}}>{detail.fichaTecnica.name}</div>
                      <div style={{color:C.gray,fontSize:11}}>{(detail.fichaTecnica.size/1024).toFixed(0)} KB</div>
                    </div>
                  </div>
                )}
                {detail.fichaStatus&&(
                  <div style={{background:st.bg,border:`1.5px solid ${st.border}`,borderRadius:10,padding:"12px 14px",display:"flex",alignItems:"center",gap:10,marginBottom:detail.fichaStatus==="reprovada"&&detail.fichaReprovacaoMotivo?10:0}}>
                    <span style={{fontSize:22}}>{st.icon}</span>
                    <span style={{color:st.fg,fontWeight:800,fontSize:14}}>{st.label}</span>
                  </div>
                )}
                {detail.fichaStatus==="reprovada"&&detail.fichaReprovacaoMotivo&&(
                  <div style={{background:"#FFEBEE",border:"1.5px solid #EF9A9A",borderRadius:10,padding:"12px 14px",marginTop:0}}>
                    <div style={{color:"#C62828",fontSize:11,fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:5}}>Motivo da Reprovação</div>
                    <p style={{color:"#7B1A1A",fontSize:14,lineHeight:1.6,margin:0}}>{detail.fichaReprovacaoMotivo}</p>
                  </div>
                )}
              </div>
            );
          })()}

          <div style={{color:C.grayL,fontSize:12,textAlign:"center",marginBottom:18}}>Criado em {detail.criadoEm}</div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <button onClick={()=>edit(detail)} style={{background:headerGrad,color:C.white,border:"none",borderRadius:12,padding:"14px",fontWeight:800,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8,fontFamily:font}}>
              <EditIcon/> Editar
            </button>
            <button onClick={()=>del(detail.id)} style={{background:C.white,color:"#C62828",border:"1.5px solid #FFCDD2",borderRadius:12,padding:"14px",fontWeight:700,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8,fontFamily:font}}>
              <TrashIcon/> Excluir
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
